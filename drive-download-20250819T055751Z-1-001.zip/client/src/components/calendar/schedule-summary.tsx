import { useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { 
  Clock, 
  Calendar, 
  User, 
  MapPin,
  Plus,
  ChevronRight
} from "lucide-react";
import { 
  format, 
  parseISO, 
  isToday, 
  isTomorrow, 
  isThisWeek,
  addDays,
  startOfWeek,
  endOfWeek
} from "date-fns";

interface Event {
  id: string;
  title?: string;
  type: string;
  customer: string;
  garment?: string;
  time: string;
  date: string;
  status?: string;
  description?: string;
}

interface ScheduleSummaryProps {
  events: Event[];
  onEventClick?: (event: Event) => void;
  onAddEvent?: () => void;
}

export function ScheduleSummary({ events, onEventClick, onAddEvent }: ScheduleSummaryProps) {
  const groupedEvents = useMemo(() => {
    const today: Event[] = [];
    const tomorrow: Event[] = [];
    const thisWeek: Event[] = [];
    const upcoming: Event[] = [];

    events.forEach(event => {
      const eventDate = parseISO(event.date);
      
      if (isToday(eventDate)) {
        today.push(event);
      } else if (isTomorrow(eventDate)) {
        tomorrow.push(event);
      } else if (isThisWeek(eventDate)) {
        thisWeek.push(event);
      } else {
        upcoming.push(event);
      }
    });

    return {
      today: today.sort((a, b) => a.time.localeCompare(b.time)),
      tomorrow: tomorrow.sort((a, b) => a.time.localeCompare(b.time)),
      thisWeek: thisWeek.sort((a, b) => {
        const dateComparison = a.date.localeCompare(b.date);
        return dateComparison !== 0 ? dateComparison : a.time.localeCompare(b.time);
      }),
      upcoming: upcoming.sort((a, b) => {
        const dateComparison = a.date.localeCompare(b.date);
        return dateComparison !== 0 ? dateComparison : a.time.localeCompare(b.time);
      })
    };
  }, [events]);

  const getEventTypeColor = (type: string) => {
    switch (type) {
      case "fitting": return "bg-blue-100 text-blue-800 border-blue-200";
      case "pickup": return "bg-green-100 text-green-800 border-green-200";
      case "return": return "bg-orange-100 text-orange-800 border-orange-200";
      case "consultation": return "bg-purple-100 text-purple-800 border-purple-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getEventIcon = (type: string) => {
    switch (type) {
      case "fitting": return <User className="w-4 h-4" />;
      case "pickup": return <MapPin className="w-4 h-4" />;
      case "return": return <MapPin className="w-4 h-4" />;
      case "consultation": return <Calendar className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const renderEventGroup = (title: string, events: Event[], showDate: boolean = false) => {
    if (events.length === 0) return null;

    return (
      <div className="space-y-3">
        <div className="flex items-center space-x-2">
          <h4 className="font-medium text-sm text-muted-foreground uppercase tracking-wide">
            {title}
          </h4>
          <Badge variant="secondary" className="text-xs">
            {events.length}
          </Badge>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
          {events.map(event => (
            <Card 
              key={event.id} 
              className={`cursor-pointer hover:shadow-md transition-all duration-200 hover:border-primary/20 ${
                event.status === 'completed' ? 'opacity-70 bg-green-50' : ''
              }`}
              onClick={() => onEventClick?.(event)}
            >
              <CardContent className="p-3">
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0 mt-0.5">
                    <div className={`p-1.5 rounded-full ${getEventTypeColor(event.type)} ${
                      event.status === 'completed' ? 'bg-green-100 text-green-800' : ''
                    }`}>
                      {event.status === 'completed' ? '✓' : getEventIcon(event.type)}
                    </div>
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <Badge variant="outline" className={`text-xs ${
                        event.status === 'completed' ? 'bg-green-100 text-green-800 border-green-200' : getEventTypeColor(event.type)
                      }`}>
                        {event.status === 'completed' ? 'Completed' : event.type}
                      </Badge>
                      <span className="text-sm font-medium text-muted-foreground">
                        {event.time}
                      </span>
                    </div>
                    
                    <h5 className={`font-medium text-sm truncate ${
                      event.status === 'completed' ? 'line-through text-muted-foreground' : ''
                    }`}>{event.customer}</h5>
                    
                    {event.garment && (
                      <p className="text-xs text-muted-foreground truncate mt-1">
                        {event.garment}
                      </p>
                    )}
                    
                    {showDate && (
                      <p className="text-xs text-muted-foreground mt-1">
                        {format(parseISO(event.date), "EEE, MMM d")}
                      </p>
                    )}
                  </div>
                  
                  <ChevronRight className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  };

  const totalEvents = Object.values(groupedEvents).reduce((sum, events) => sum + events.length, 0);

  return (
    <Card className="w-full">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg">Schedule Overview</CardTitle>
            {totalEvents > 0 && (
              <p className="text-sm text-muted-foreground">
                {totalEvents} upcoming appointment{totalEvents !== 1 ? 's' : ''}
              </p>
            )}
          </div>
          <Button size="sm" onClick={onAddEvent}>
            <Plus className="w-4 h-4 mr-2" />
            Add Event
          </Button>
        </div>
      </CardHeader>
      
      <CardContent>
        {totalEvents === 0 ? (
          <div className="text-center py-8">
            <Calendar className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground mb-4">No upcoming appointments</p>
            <Button variant="outline" onClick={onAddEvent}>
              <Plus className="w-4 h-4 mr-2" />
              Schedule First Event
            </Button>
          </div>
        ) : (
          <div className="space-y-6">
            {renderEventGroup("Today", groupedEvents.today)}
            
            {groupedEvents.tomorrow.length > 0 && (
              <>
                {groupedEvents.today.length > 0 && <Separator />}
                {renderEventGroup("Tomorrow", groupedEvents.tomorrow)}
              </>
            )}
            
            {groupedEvents.thisWeek.length > 0 && (
              <>
                {(groupedEvents.today.length > 0 || groupedEvents.tomorrow.length > 0) && <Separator />}
                {renderEventGroup("This Week", groupedEvents.thisWeek, true)}
              </>
            )}
            
            {groupedEvents.upcoming.length > 0 && (
              <>
                <Separator />
                {renderEventGroup("Upcoming", groupedEvents.upcoming.slice(0, 8), true)}
                {groupedEvents.upcoming.length > 8 && (
                  <div className="text-center">
                    <Button variant="ghost" className="text-sm">
                      View {groupedEvents.upcoming.length - 8} more events
                    </Button>
                  </div>
                )}
              </>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}