import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  ChevronLeft, 
  ChevronRight, 
  Plus, 
  Calendar as CalendarIcon,
  Clock,
  Users,
  MapPin
} from "lucide-react";
import { 
  format, 
  startOfMonth, 
  endOfMonth, 
  startOfWeek, 
  endOfWeek, 
  eachDayOfInterval, 
  isSameMonth, 
  isSameDay, 
  addMonths, 
  subMonths,
  addWeeks,
  subWeeks,
  addDays,
  subDays,
  startOfDay,
  endOfDay,
  parseISO,
  isToday,
  isTomorrow,
  isThisWeek
} from "date-fns";

type ViewMode = "month" | "week" | "day";

interface Event {
  id: string;
  title: string;
  type: string;
  customer: string;
  garment?: string;
  time: string;
  date: string;
  status?: string;
  description?: string;
}

interface CalendarViewProps {
  events: Event[];
  onEventClick?: (event: Event) => void;
  onDateClick?: (date: Date) => void;
  onAddEvent?: (date: Date, time?: string) => void;
}

export function CalendarView({ events, onEventClick, onDateClick, onAddEvent }: CalendarViewProps) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [viewMode, setViewMode] = useState<ViewMode>("month");

  // Group events by date for easy lookup
  const eventsByDate = useMemo(() => {
    const grouped: Record<string, Event[]> = {};
    events.forEach(event => {
      const dateKey = format(parseISO(event.date), "yyyy-MM-dd");
      if (!grouped[dateKey]) {
        grouped[dateKey] = [];
      }
      grouped[dateKey].push(event);
    });
    return grouped;
  }, [events]);

  const navigateDate = (direction: "prev" | "next") => {
    if (viewMode === "month") {
      setCurrentDate(direction === "prev" ? subMonths(currentDate, 1) : addMonths(currentDate, 1));
    } else if (viewMode === "week") {
      setCurrentDate(direction === "prev" ? subWeeks(currentDate, 1) : addWeeks(currentDate, 1));
    } else {
      setCurrentDate(direction === "prev" ? subDays(currentDate, 1) : addDays(currentDate, 1));
    }
  };

  const getViewTitle = () => {
    if (viewMode === "month") {
      return format(currentDate, "MMMM yyyy");
    } else if (viewMode === "week") {
      const weekStart = startOfWeek(currentDate);
      const weekEnd = endOfWeek(currentDate);
      return `${format(weekStart, "MMM d")} - ${format(weekEnd, "MMM d, yyyy")}`;
    } else {
      return format(currentDate, "EEEE, MMMM d, yyyy");
    }
  };

  const getEventTypeColor = (type: string) => {
    switch (type) {
      case "fitting": return "bg-blue-100 text-blue-800 border-blue-200";
      case "pickup": return "bg-green-100 text-green-800 border-green-200";
      case "return": return "bg-orange-100 text-orange-800 border-orange-200";
      case "consultation": return "bg-purple-100 text-purple-800 border-purple-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const renderMonthView = () => {
    const monthStart = startOfMonth(currentDate);
    const monthEnd = endOfMonth(currentDate);
    const calendarStart = startOfWeek(monthStart);
    const calendarEnd = endOfWeek(monthEnd);
    const calendarDays = eachDayOfInterval({ start: calendarStart, end: calendarEnd });

    return (
      <div className="grid grid-cols-7 gap-px bg-border">
        {/* Day headers */}
        {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map(day => (
          <div key={day} className="bg-muted p-2 text-center text-sm font-medium">
            {day}
          </div>
        ))}
        
        {/* Calendar days */}
        {calendarDays.map(day => {
          const dateKey = format(day, "yyyy-MM-dd");
          const dayEvents = eventsByDate[dateKey] || [];
          const isCurrentMonth = isSameMonth(day, currentDate);
          const isSelected = isSameDay(day, currentDate);
          
          return (
            <div
              key={day.toISOString()}
              className={`min-h-32 bg-background p-1 cursor-pointer hover:bg-muted/50 transition-colors ${
                !isCurrentMonth ? "text-muted-foreground bg-muted/20" : ""
              } ${isSelected ? "ring-2 ring-primary" : ""} ${isToday(day) ? "bg-primary/5" : ""}`}
              onClick={() => onDateClick?.(day)}
            >
              <div className="flex items-center justify-between mb-1">
                <span className={`text-sm ${isToday(day) ? "font-bold text-primary" : ""}`}>
                  {format(day, "d")}
                </span>
                {dayEvents.length > 0 && (
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-4 w-4 p-0"
                    onClick={(e) => {
                      e.stopPropagation();
                      onAddEvent?.(day);
                    }}
                  >
                    <Plus className="w-3 h-3" />
                  </Button>
                )}
              </div>
              
              <div className="space-y-1">
                {dayEvents.slice(0, 3).map(event => (
                  <div
                    key={event.id}
                    className={`text-xs p-1 rounded border cursor-pointer truncate ${getEventTypeColor(event.type)} ${
                      event.status === 'completed' ? 'opacity-60 line-through' : ''
                    }`}
                    onClick={(e) => {
                      e.stopPropagation();
                      onEventClick?.(event);
                    }}
                  >
                    <div className="font-medium flex items-center space-x-1">
                      <span>{event.time}</span>
                      {event.status === 'completed' && <span className="text-green-600">✓</span>}
                    </div>
                    <div className="truncate">{event.title || event.type}</div>
                  </div>
                ))}
                {dayEvents.length > 3 && (
                  <div className="text-xs text-muted-foreground">
                    +{dayEvents.length - 3} more
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  const renderWeekView = () => {
    const weekStart = startOfWeek(currentDate);
    const weekDays = eachDayOfInterval({ start: weekStart, end: endOfWeek(currentDate) });

    return (
      <div className="grid grid-cols-8 gap-px bg-border h-96">
        {/* Time column header */}
        <div className="bg-muted p-2 text-center text-sm font-medium">Time</div>
        
        {/* Day headers */}
        {weekDays.map(day => (
          <div key={day.toISOString()} className={`bg-muted p-2 text-center text-sm font-medium ${isToday(day) ? "bg-primary/10" : ""}`}>
            <div>{format(day, "EEE")}</div>
            <div className={`${isToday(day) ? "font-bold text-primary" : ""}`}>{format(day, "d")}</div>
          </div>
        ))}

        {/* Time slots */}
        {Array.from({ length: 12 }, (_, i) => i + 8).map(hour => (
          <div key={hour} className="contents">
            <div className="bg-background p-2 text-xs text-muted-foreground border-r">
              {format(new Date().setHours(hour, 0), "h:mm a")}
            </div>
            {weekDays.map(day => {
              const dateKey = format(day, "yyyy-MM-dd");
              const dayEvents = eventsByDate[dateKey] || [];
              const hourEvents = dayEvents.filter(event => {
                const eventHour = parseInt(event.time.split(":")[0]);
                return eventHour === hour;
              });

              return (
                <div
                  key={`${day.toISOString()}-${hour}`}
                  className="bg-background p-1 border-b cursor-pointer hover:bg-muted/50 min-h-16"
                  onClick={() => onAddEvent?.(day, `${hour}:00`)}
                >
                  {hourEvents.map(event => (
                    <div
                      key={event.id}
                      className={`text-xs p-1 rounded border mb-1 cursor-pointer ${getEventTypeColor(event.type)} ${
                        event.status === 'completed' ? 'opacity-60 line-through' : ''
                      }`}
                      onClick={(e) => {
                        e.stopPropagation();
                        onEventClick?.(event);
                      }}
                    >
                      <div className="font-medium flex items-center space-x-1">
                        <span>{event.customer}</span>
                        {event.status === 'completed' && <span className="text-green-600">✓</span>}
                      </div>
                      <div className="truncate">{event.type}</div>
                    </div>
                  ))}
                </div>
              );
            })}
          </div>
        ))}
      </div>
    );
  };

  const renderDayView = () => {
    const dateKey = format(currentDate, "yyyy-MM-dd");
    const dayEvents = eventsByDate[dateKey] || [];

    return (
      <div className="space-y-4">
        <div className="grid grid-cols-1 gap-px">
          {Array.from({ length: 14 }, (_, i) => i + 7).map(hour => {
            const hourEvents = dayEvents.filter(event => {
              const eventHour = parseInt(event.time.split(":")[0]);
              return eventHour === hour;
            });

            return (
              <div key={hour} className="flex border-b">
                <div className="w-20 p-3 text-sm text-muted-foreground bg-muted/30">
                  {format(new Date().setHours(hour, 0), "h:mm a")}
                </div>
                <div 
                  className="flex-1 p-3 min-h-16 cursor-pointer hover:bg-muted/20"
                  onClick={() => onAddEvent?.(currentDate, `${hour}:00`)}
                >
                  {hourEvents.map(event => (
                    <Card key={event.id} className="mb-2 cursor-pointer hover:shadow-md transition-shadow" onClick={(e) => {
                      e.stopPropagation();
                      onEventClick?.(event);
                    }}>
                      <CardContent className="p-3">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-1">
                              <Badge variant="outline" className={getEventTypeColor(event.type)}>
                                {event.type}
                              </Badge>
                              <span className="text-sm font-medium">{event.time}</span>
                            </div>
                            <h4 className="font-medium">{event.customer}</h4>
                            {event.garment && (
                              <p className="text-sm text-muted-foreground">{event.garment}</p>
                            )}
                          </div>
                          <div className="flex items-center space-x-1 text-muted-foreground">
                            <Clock className="w-4 h-4" />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-4">
      {/* Calendar Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <h2 className="text-xl font-semibold">{getViewTitle()}</h2>
          <div className="flex items-center space-x-1">
            <Button variant="outline" size="sm" onClick={() => navigateDate("prev")}>
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={() => setCurrentDate(new Date())}>
              Today
            </Button>
            <Button variant="outline" size="sm" onClick={() => navigateDate("next")}>
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <Select value={viewMode} onValueChange={(value) => setViewMode(value as ViewMode)}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="month">Month</SelectItem>
              <SelectItem value="week">Week</SelectItem>
              <SelectItem value="day">Day</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={() => onAddEvent?.(new Date())}>
            <Plus className="w-4 h-4 mr-2" />
            Add Event
          </Button>
        </div>
      </div>

      {/* Calendar Content */}
      <Card>
        <CardContent className="p-0">
          {viewMode === "month" && renderMonthView()}
          {viewMode === "week" && renderWeekView()}
          {viewMode === "day" && renderDayView()}
        </CardContent>
      </Card>
    </div>
  );
}