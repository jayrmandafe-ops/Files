import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Calendar,
  Clock,
  User,
  MapPin,
  Trash2,
  Save,
  X
} from "lucide-react";
import { format } from "date-fns";

interface EventFormData {
  id?: string;
  title?: string;
  type: string;
  customer: string;
  garment?: string;
  time: string;
  date: string;
  status?: string;
  description?: string;
}

interface EventDialogProps {
  event?: EventFormData | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (event: EventFormData) => void;
  onDelete?: (eventId: string) => void;
  customers?: Array<{ id: string; name: string }>;
  garments?: Array<{ id: string; name: string }>;
  defaultDate?: Date;
  defaultTime?: string;
}

const EVENT_TYPES = [
  { value: "fitting", label: "Fitting Appointment", color: "bg-blue-100 text-blue-800" },
  { value: "pickup", label: "Pickup", color: "bg-green-100 text-green-800" },
  { value: "return", label: "Return", color: "bg-orange-100 text-orange-800" },
  { value: "consultation", label: "Consultation", color: "bg-purple-100 text-purple-800" },
  { value: "delivery", label: "Delivery", color: "bg-indigo-100 text-indigo-800" },
  { value: "custom", label: "Custom Event", color: "bg-gray-100 text-gray-800" }
];

export function EventDialog({ 
  event, 
  isOpen, 
  onClose, 
  onSave, 
  onDelete, 
  customers = [], 
  garments = [],
  defaultDate,
  defaultTime 
}: EventDialogProps) {
  const [formData, setFormData] = useState<EventFormData>({
    title: "",
    type: "fitting",
    customer: "",
    garment: "",
    time: "09:00",
    date: format(new Date(), "yyyy-MM-dd"),
    status: "scheduled",
    description: ""
  });

  const [isEditing, setIsEditing] = useState(!event);

  useEffect(() => {
    if (event) {
      setFormData(event);
      setIsEditing(false);
    } else {
      setFormData({
        title: "",
        type: "fitting",
        customer: "",
        garment: "",
        time: defaultTime || "09:00",
        date: defaultDate ? format(defaultDate, "yyyy-MM-dd") : format(new Date(), "yyyy-MM-dd"),
        status: "scheduled",
        description: ""
      });
      setIsEditing(true);
    }
  }, [event, defaultDate, defaultTime]);

  const handleSave = () => {
    onSave(formData);
    onClose();
  };

  const handleDelete = () => {
    if (event?.id && onDelete) {
      onDelete(event.id);
      onClose();
    }
  };

  const getEventTypeInfo = (type: string) => {
    return EVENT_TYPES.find(t => t.value === type) || EVENT_TYPES[0];
  };

  const selectedCustomer = customers.find(c => c.id === formData.customer);
  const selectedGarment = garments.find(g => g.id === formData.garment);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Calendar className="w-5 h-5" />
            <span>{event ? (isEditing ? "Edit Event" : "Event Details") : "New Event"}</span>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Event Type */}
          <div className="space-y-1">
            <Label className="text-sm">Event Type</Label>
            {isEditing ? (
              <Select value={formData.type} onValueChange={(value) => setFormData({ ...formData, type: value })}>
                <SelectTrigger className="h-9">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {EVENT_TYPES.map(type => (
                    <SelectItem key={type.value} value={type.value}>
                      <div className="flex items-center space-x-2">
                        <div className={`w-3 h-3 rounded-full ${type.color}`} />
                        <span>{type.label}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            ) : (
              <div className="flex items-center space-x-2">
                <Badge className={getEventTypeInfo(formData.type).color}>
                  {getEventTypeInfo(formData.type).label}
                </Badge>
              </div>
            )}
          </div>

          {/* Date and Time */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label htmlFor="date" className="text-sm">Date</Label>
              {isEditing ? (
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  className="h-9"
                />
              ) : (
                <div className="flex items-center space-x-2 text-sm">
                  <Calendar className="w-4 h-4 text-muted-foreground" />
                  <span>{format(new Date(formData.date), "MMM d, yyyy")}</span>
                </div>
              )}
            </div>
            
            <div className="space-y-1">
              <Label htmlFor="time" className="text-sm">Time</Label>
              {isEditing ? (
                <Input
                  id="time"
                  type="time"
                  value={formData.time}
                  onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                  className="h-9"
                />
              ) : (
                <div className="flex items-center space-x-2 text-sm">
                  <Clock className="w-4 h-4 text-muted-foreground" />
                  <span>{formData.time}</span>
                </div>
              )}
            </div>
          </div>

          {/* Customer */}
          <div className="space-y-1">
            <Label className="text-sm">Customer</Label>
            {isEditing ? (
              <Select value={formData.customer} onValueChange={(value) => setFormData({ ...formData, customer: value })}>
                <SelectTrigger className="h-9">
                  <SelectValue placeholder="Select a customer" />
                </SelectTrigger>
                <SelectContent>
                  {customers.map(customer => (
                    <SelectItem key={customer.id} value={customer.id}>
                      {customer.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            ) : (
              <div className="flex items-center space-x-2 text-sm">
                <User className="w-4 h-4 text-muted-foreground" />
                <span>{selectedCustomer?.name || formData.customer}</span>
              </div>
            )}
          </div>

          {/* Garment (optional) */}
          <div className="space-y-1">
            <Label className="text-sm">Garment (Optional)</Label>
            {isEditing ? (
              <Select value={formData.garment} onValueChange={(value) => setFormData({ ...formData, garment: value })}>
                <SelectTrigger className="h-9">
                  <SelectValue placeholder="Select a garment" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">No garment</SelectItem>
                  {garments.map(garment => (
                    <SelectItem key={garment.id} value={garment.id}>
                      {garment.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            ) : (
              selectedGarment && (
                <div className="flex items-center space-x-2 text-sm">
                  <MapPin className="w-4 h-4 text-muted-foreground" />
                  <span>{selectedGarment.name}</span>
                </div>
              )
            )}
          </div>

          {/* Status */}
          <div className="space-y-1">
            <Label className="text-sm">Status</Label>
            {isEditing ? (
              <Select value={formData.status || "scheduled"} onValueChange={(value) => setFormData({ ...formData, status: value })}>
                <SelectTrigger className="h-9">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="scheduled">Scheduled</SelectItem>
                  <SelectItem value="confirmed">Confirmed</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                  <SelectItem value="no_show">No Show</SelectItem>
                </SelectContent>
              </Select>
            ) : (
              <div className="flex items-center space-x-2">
                <div className={`w-3 h-3 rounded-full ${
                  formData.status === 'completed' ? 'bg-green-500' :
                  formData.status === 'in_progress' ? 'bg-blue-500' :
                  formData.status === 'confirmed' ? 'bg-yellow-500' :
                  formData.status === 'cancelled' ? 'bg-red-500' :
                  formData.status === 'no_show' ? 'bg-gray-500' :
                  'bg-orange-500'
                }`} />
                <span className="capitalize text-sm">{formData.status?.replace('_', ' ') || 'scheduled'}</span>
              </div>
            )}
          </div>

          {/* Description */}
          <div className="space-y-1">
            <Label htmlFor="description" className="text-sm">Notes (Optional)</Label>
            {isEditing ? (
              <Textarea
                id="description"
                value={formData.description || ""}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Add any additional notes or details"
                rows={2}
                className="resize-none"
              />
            ) : (
              formData.description && (
                <p className="text-sm text-muted-foreground">{formData.description}</p>
              )
            )}
          </div>

          <Separator className="my-3" />

          {/* Actions */}
          <div className="flex items-center justify-between pt-2">
            <div>
              {event && !isEditing && onDelete && (
                <Button variant="destructive" size="sm" onClick={handleDelete}>
                  <Trash2 className="w-4 h-4 mr-1" />
                  Delete
                </Button>
              )}
            </div>
            
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" onClick={onClose}>
                Cancel
              </Button>
              
              {event && !isEditing ? (
                <Button size="sm" onClick={() => setIsEditing(true)}>
                  Edit
                </Button>
              ) : (
                <Button size="sm" onClick={handleSave}>
                  <Save className="w-4 h-4 mr-1" />
                  {event ? "Save" : "Create"}
                </Button>
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}