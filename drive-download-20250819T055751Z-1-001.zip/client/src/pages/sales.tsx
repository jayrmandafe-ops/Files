import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BarChart3, TrendingUp } from "lucide-react";
import { SalesChart } from "@/components/charts/sales-chart";

export default function Sales() {
  const { data: sales, isLoading } = useQuery({
    queryKey: ["/api/sales"],
  });

  const { data: dashboard } = useQuery({
    queryKey: ["/api/dashboard"],
  });

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-48"></div>
          <div className="h-96 bg-gray-200 rounded-xl"></div>
        </div>
      </div>
    );
  }

  const totalSales = sales?.reduce((sum: number, sale: any) => sum + parseFloat(sale.amount || '0'), 0) || 0;

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Sales</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            View sales performance and manage customer balances
          </p>
        </div>
        <Button>
          <TrendingUp className="w-4 h-4 mr-2" />
          Export Report
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold">Total Sales</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">₱{totalSales.toLocaleString()}</p>
            <p className="text-sm text-muted-foreground mt-1">All time</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold">This Month</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">₱{(totalSales * 0.15).toLocaleString()}</p>
            <p className="text-sm text-green-600 mt-1">+15% vs last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold">Average Sale</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">
              ₱{sales?.length > 0 ? Math.round(totalSales / sales.length).toLocaleString() : '0'}
            </p>
            <p className="text-sm text-muted-foreground mt-1">Per transaction</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <BarChart3 className="w-5 h-5 mr-2" />
            Sales Over Time
          </CardTitle>
        </CardHeader>
        <CardContent>
          <SalesChart data={dashboard?.salesOverTime || []} />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Recent Transactions</CardTitle>
        </CardHeader>
        <CardContent>
          {sales?.length > 0 ? (
            <div className="space-y-4">
              {sales.slice(0, 10).map((sale: any) => (
                <div key={sale.id} className="flex items-center justify-between p-4 border border-border rounded-lg">
                  <div>
                    <p className="font-medium">₱{parseFloat(sale.amount).toLocaleString()}</p>
                    <p className="text-sm text-muted-foreground">
                      {sale.salesType} • {new Date(sale.transactionDate).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-muted-foreground">Order: {sale.orderId.slice(0, 8)}</p>
                    <p className="text-xs text-muted-foreground">{sale.paymentMethod || 'Cash'}</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <BarChart3 className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">No sales transactions found</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
