import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Calendar, Download, TrendingUp, TrendingDown } from "lucide-react";
import { SalesChart } from "@/components/charts/sales-chart";

type TimePeriod = 'today' | 'week' | 'month' | 'quarter' | 'year' | 'custom';

export default function Dashboard() {
  const [selectedPeriod, setSelectedPeriod] = useState<TimePeriod>('week');
  const [doNotCompare, setDoNotCompare] = useState(false);

  const { data: metrics, isLoading } = useQuery({
    queryKey: ["/api/dashboard"],
  });

  // Provide default values to prevent type errors
  const safeMetrics = {
    dailySales: metrics?.dailySales || 0,
    avgOrderValue: metrics?.avgOrderValue || 0,
    dailyCustomers: metrics?.dailyCustomers || 0,
    salesOverTime: metrics?.salesOverTime || [],
    topGarments: metrics?.topGarments || [],
    recentOrders: metrics?.recentOrders || [],
    upcomingSchedules: metrics?.upcomingSchedules || []
  };

  if (isLoading) {
    return (
      <div className="replit-container">
        <div className="animate-pulse space-y-3">
          <div className="h-6 bg-muted rounded w-32"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-20 bg-muted rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const periodLabels: Record<TimePeriod, string> = {
    today: 'Today',
    week: 'Week', 
    month: 'Month',
    quarter: 'Quarter',
    year: 'Year',
    custom: 'Custom date'
  };

  const getChangeText = (period: TimePeriod) => {
    switch (period) {
      case 'today': return 'From yesterday';
      case 'week': return 'From last week'; 
      case 'month': return 'From last month';
      case 'quarter': return 'From last quarter';
      case 'year': return 'From last year';
      default: return 'From last period';
    }
  };

  return (
    <div className="replit-container">
      {/* Header with Time Period Selection */}
      <div className="replit-header">
        <div className="flex items-center space-x-4">
          {(Object.keys(periodLabels) as TimePeriod[]).map((period) => (
            <button
              key={period}
              onClick={() => setSelectedPeriod(period)}
              className={`replit-tab-button ${
                selectedPeriod === period ? 'replit-tab-active' : 'replit-tab-inactive'
              }`}
            >
              {periodLabels[period]}
            </button>
          ))}
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="replit-toggle">
            <Switch
              checked={doNotCompare}
              onCheckedChange={setDoNotCompare}
              className="mr-2 scale-75"
            />
            <span>Do not compare</span>
          </div>
          <Button variant="outline" size="sm" className="text-xs">
            <Download className="w-3 h-3 mr-1.5" />
            Export
          </Button>
        </div>
      </div>

      {/* Compact Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Gross Revenue */}
        <Card className="replit-metric-card">
          <CardContent className="p-3">
            <div className="replit-metric-label">Gross revenue</div>
            <div className="replit-metric-value">
              ₱{(safeMetrics.dailySales * 7 || 14509).toLocaleString()}
            </div>
            {!doNotCompare && (
              <div className="replit-metric-change text-green-600">
                <TrendingUp className="w-3 h-3 mr-1" />
                <span className="mr-1">21%</span>
                <span className="text-muted-foreground">{getChangeText(selectedPeriod)}</span>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Avg Order Value */}
        <Card className="replit-metric-card">
          <CardContent className="p-3">
            <div className="replit-metric-label">Avg. order value</div>
            <div className="replit-metric-value">
              ₱{Math.round(safeMetrics.avgOrderValue || 204)}
            </div>
            {!doNotCompare && (
              <div className="replit-metric-change text-green-600">
                <TrendingUp className="w-3 h-3 mr-1" />
                <span className="mr-1">₱53</span>
                <span className="text-muted-foreground">{getChangeText(selectedPeriod)}</span>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Conversion Rate */}
        <Card className="replit-metric-card">
          <CardContent className="p-3">
            <div className="replit-metric-label">Conversion rate</div>
            <div className="replit-metric-value">12%</div>
            {!doNotCompare && (
              <div className="replit-metric-change text-green-600">
                <TrendingUp className="w-3 h-3 mr-1" />
                <span className="mr-1">4%</span>
                <span className="text-muted-foreground">{getChangeText(selectedPeriod)}</span>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Customers */}
        <Card className="replit-metric-card">
          <CardContent className="p-3">
            <div className="replit-metric-label">Customers</div>
            <div className="replit-metric-value">
              {(safeMetrics.dailyCustomers * 7 || 306)}
            </div>
            {!doNotCompare && (
              <div className="replit-metric-change text-green-600">
                <TrendingUp className="w-3 h-3 mr-1" />
                <span className="mr-1">114</span>
                <span className="text-muted-foreground">{getChangeText(selectedPeriod)}</span>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Main Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-8 gap-3 mt-6">
        {/* Top Garments - 1.5/8 width */}
        <Card className="lg:col-span-3">
          <div className="p-3 border-b">
            <h3 className="replit-title">Top garments by sales</h3>
          </div>
          <div className="p-3 space-y-3">
            {safeMetrics.topGarments.length > 0 ? (
              safeMetrics.topGarments.slice(0, 6).map((garment: any, index: number) => (
                <div key={index} className="flex items-center justify-between text-xs">
                  <div className="flex items-center">
                    <div className="w-8 h-8 bg-muted rounded mr-2"></div>
                    <div>
                      <div className="font-medium">{garment.name}</div>
                      <div className="text-muted-foreground text-xs">Traditional • Abaca</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium">₱{garment.sales.toLocaleString()}</div>
                    <div className="text-green-600 text-xs">+23%</div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-xs text-muted-foreground">No sales data available</div>
            )}
          </div>
        </Card>

        {/* Sales Chart - 5/8 width (2.5 metric cards) */}
        <Card className="lg:col-span-5">
          <div className="p-3 border-b">
            <h3 className="replit-title">Sales over time</h3>
            <p className="replit-subtitle">Total sales: ₱{(safeMetrics.salesOverTime.reduce((sum: number, item: any) => sum + item.amount, 0) || 0).toLocaleString()}</p>
          </div>
          <div className="p-3">
            <SalesChart data={safeMetrics.salesOverTime} />
          </div>
        </Card>
      </div>

      {/* Bottom Analytics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-6">
        {/* Recent Orders */}
        <Card>
          <div className="p-3 border-b">
            <h3 className="replit-title">Recent orders</h3>
          </div>
          <div className="p-3 space-y-3">
            {safeMetrics.recentOrders.length > 0 ? (
              safeMetrics.recentOrders.slice(0, 4).map((order: any) => (
                <div key={order.id} className="flex items-center justify-between text-xs">
                  <div>
                    <div className="font-medium">#{order.id.slice(0, 8)}</div>
                    <div className="text-muted-foreground">{order.orderType} • {order.status}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium">₱{parseFloat(order.totalAmount || '0').toLocaleString()}</div>
                    <Badge variant={order.status === 'confirmed' ? 'default' : 'secondary'} className="text-xs">
                      {order.status}
                    </Badge>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-xs text-muted-foreground">No recent orders</div>
            )}
          </div>
        </Card>

        {/* Upcoming Schedule */}
        <Card>
          <div className="p-3 border-b">
            <h3 className="replit-title">Upcoming schedule</h3>
          </div>
          <div className="p-3 space-y-3">
            {safeMetrics.upcomingSchedules.length > 0 ? (
              safeMetrics.upcomingSchedules.slice(0, 4).map((schedule: any) => (
                <div key={schedule.id} className="flex items-center space-x-2 text-xs">
                  <div className={`w-2 h-2 rounded-full ${
                    schedule.type === 'fitting' ? 'bg-red-500' :
                    schedule.type === 'pickup' ? 'bg-yellow-500' :
                    schedule.type === 'return' ? 'bg-green-500' : 'bg-blue-500'
                  }`}></div>
                  <div className="flex-1">
                    <div className="font-medium">{schedule.type}</div>
                    <div className="text-muted-foreground">
                      {new Date(schedule.scheduledDate).toLocaleDateString()} at{' '}
                      {new Date(schedule.scheduledDate).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-xs text-muted-foreground">No upcoming schedules</div>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}