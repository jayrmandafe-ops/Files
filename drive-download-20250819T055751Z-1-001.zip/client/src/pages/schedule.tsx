import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { CalendarView } from "@/components/calendar/calendar-view";
import { ScheduleSummary } from "@/components/calendar/schedule-summary";
import { EventDialog } from "@/components/calendar/event-dialog";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

interface Schedule {
  id: string;
  customerId: string;
  orderId?: string;
  type: string;
  scheduledDate: string;
  status: string;
  notes?: string;
}

interface Customer {
  id: string;
  name: string;
}

interface Garment {
  id: string;
  name: string;
}

interface Event {
  id: string;
  title?: string;
  type: string;
  customer: string;
  garment?: string;
  time: string;
  date: string;
  status?: string;
  description?: string;
}

export default function Schedule() {
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
  const [isEventDialogOpen, setIsEventDialogOpen] = useState(false);
  const [defaultDate, setDefaultDate] = useState<Date | undefined>();
  const [defaultTime, setDefaultTime] = useState<string | undefined>();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: schedules, isLoading: schedulesLoading } = useQuery({
    queryKey: ["/api/schedules"],
  });

  const { data: customers } = useQuery({
    queryKey: ["/api/customers"],
  });

  const { data: garments } = useQuery({
    queryKey: ["/api/garments"],
  });

  // Transform schedules to events format for calendar
  const events = useMemo(() => {
    if (!schedules || !Array.isArray(schedules) || !customers || !Array.isArray(customers)) return [];
    
    return schedules.map((schedule: Schedule) => {
      const customer = customers.find((c: Customer) => c.id === schedule.customerId);
      const scheduledDate = new Date(schedule.scheduledDate);
      
      return {
        id: schedule.id,
        title: `${schedule.type} - ${customer?.name || 'Customer'}`,
        type: schedule.type,
        customer: customer?.name || `Customer ${schedule.customerId?.slice(0, 8) || 'Unknown'}`,
        time: format(scheduledDate, "HH:mm"),
        date: format(scheduledDate, "yyyy-MM-dd"),
        status: schedule.status,
        description: schedule.notes,
      };
    });
  }, [schedules, customers]);

  const saveEventMutation = useMutation({
    mutationFn: async (event: Event) => {
      const scheduleData = {
        customerId: Array.isArray(customers) ? customers.find((c: Customer) => c.name === event.customer)?.id || event.customer : event.customer,
        type: event.type,
        scheduledDate: new Date(`${event.date}T${event.time}:00`).toISOString(),
        status: event.status || "scheduled",
        notes: event.description,
      };

      if (event.id && Array.isArray(schedules) && schedules.find((s: Schedule) => s.id === event.id)) {
        // Update existing
        const response = await fetch(`/api/schedules/${event.id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(scheduleData),
        });
        return response.json();
      } else {
        // Create new
        const response = await fetch("/api/schedules", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(scheduleData),
        });
        return response.json();
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/schedules"] });
      toast({
        title: "Event saved",
        description: "The appointment has been saved successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save the appointment. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteEventMutation = useMutation({
    mutationFn: async (eventId: string) => {
      const response = await fetch(`/api/schedules/${eventId}`, {
        method: "DELETE",
      });
      return response;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/schedules"] });
      toast({
        title: "Event deleted",
        description: "The appointment has been deleted successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete the appointment. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleEventClick = (event: Event) => {
    setSelectedEvent(event);
    setIsEventDialogOpen(true);
  };

  const handleDateClick = (date: Date) => {
    setDefaultDate(date);
    setDefaultTime(undefined);
    setSelectedEvent(null);
    setIsEventDialogOpen(true);
  };

  const handleAddEvent = (date?: Date, time?: string) => {
    setDefaultDate(date || new Date());
    setDefaultTime(time);
    setSelectedEvent(null);
    setIsEventDialogOpen(true);
  };

  const handleSaveEvent = (event: Event) => {
    saveEventMutation.mutate(event as Event);
  };

  const handleDeleteEvent = (eventId: string) => {
    deleteEventMutation.mutate(eventId);
  };

  if (schedulesLoading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-48"></div>
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            <div className="lg:col-span-3 h-96 bg-gray-200 rounded-xl"></div>
            <div className="h-96 bg-gray-200 rounded-xl"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Calendar View - Full Width */}
      <div className="w-full">
        <CalendarView
          events={events}
          onEventClick={handleEventClick}
          onDateClick={handleDateClick}
          onAddEvent={handleAddEvent}
        />
      </div>

      {/* Schedule Summary Panel - Horizontal at Bottom */}
      <div className="w-full">
        <ScheduleSummary
          events={events}
          onEventClick={handleEventClick}
          onAddEvent={() => handleAddEvent()}
        />
      </div>

      {/* Event Dialog */}
      <EventDialog
        event={selectedEvent}
        isOpen={isEventDialogOpen}
        onClose={() => {
          setIsEventDialogOpen(false);
          setSelectedEvent(null);
          setDefaultDate(undefined);
          setDefaultTime(undefined);
        }}
        onSave={handleSaveEvent}
        onDelete={handleDeleteEvent}
        customers={Array.isArray(customers) ? customers as Array<{ id: string; name: string }> : []}
        garments={Array.isArray(garments) ? garments as Array<{ id: string; name: string }> : []}
        defaultDate={defaultDate}
        defaultTime={defaultTime}
      />
    </div>
  );
}
