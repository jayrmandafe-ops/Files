import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Plus, User, Users, Calendar as CalendarIcon, Ruler, Trash2 } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";

// ============================================
// DATA SCHEMAS AND VALIDATION
// ============================================

// Female measurements schema - 25 fields as requested
const femaleMeasurements = z.object({
  shoulder: z.string().optional(),
  chestBack: z.string().optional(),
  chestFront: z.string().optional(),
  bust: z.string().optional(),
  bustPoint: z.string().optional(),
  bustDistance: z.string().optional(),
  empireCircum: z.string().optional(),
  figure: z.string().optional(),
  waist: z.string().optional(),
  hip1: z.string().optional(),
  hip2: z.string().optional(),
  armHole: z.string().optional(),
  sleeveLength: z.string().optional(),
  armAround: z.string().optional(),
  dressLength: z.string().optional(),
  blouseLength: z.string().optional(),
  skirtLength: z.string().optional(),
  depthNeck: z.string().optional(),
  neckCircum: z.string().optional(),
  pantsLength: z.string().optional(),
  crotch: z.string().optional(),
  thigh: z.string().optional(),
  knee: z.string().optional(),
  bottom: z.string().optional(),
  belt: z.string().optional(),
});

// Male measurements schema - 18 fields as requested
const maleMeasurements = z.object({
  shoulder: z.string().optional(),
  chestFront: z.string().optional(),
  bust: z.string().optional(),
  figure: z.string().optional(),
  waist: z.string().optional(),
  hip1: z.string().optional(),
  hip2: z.string().optional(),
  armHole: z.string().optional(),
  sleeveLength: z.string().optional(),
  armAround: z.string().optional(),
  barongLength: z.string().optional(),
  neckCircum: z.string().optional(),
  pantsLength: z.string().optional(),
  crotch: z.string().optional(),
  thigh: z.string().optional(),
  knee: z.string().optional(),
  bottom: z.string().optional(),
  belt: z.string().optional(),
});

// Customer schema for individual customers in fittings
const customerSchema = z.object({
  name: z.string().min(1, "Name is required"),
  phone: z.string().min(1, "Phone number is required"),
  address: z.string().optional(),
  gender: z.enum(["male", "female"]),
  silhouette: z.enum(["filipiniana", "barong", "wedding_gown", "suite", "casual_wear", "kids_wear", "party_dress", "evening_gown"]),
  measurements: z.union([femaleMeasurements, maleMeasurements]),
});

// Main fitting form schema
const fittingSchema = z.object({
  fittingType: z.enum(["individual", "group"]),
  bookingDate: z.date(),
  firstFittingDate: z.date().optional(),
  lastFittingDate: z.date().optional(),
  pickupDate: z.date().optional(),
  totalAmount: z.string().min(1, "Total amount is required"),
  depositAmount: z.string().optional(),
  asOfDate: z.date().optional(),
  category: z.enum(["first_use", "to_own", "to_rent", "modified"]),
  customers: z.array(customerSchema).min(1, "At least one customer is required"),
});

type FittingFormData = z.infer<typeof fittingSchema>;

// ============================================
// CONFIGURATION DATA
// ============================================

// Silhouette dropdown options
const silhouetteOptions = [
  { value: "filipiniana", label: "Filipiniana" },
  { value: "barong", label: "Barong" },
  { value: "wedding_gown", label: "Wedding Gown" },
  { value: "suite", label: "Suite" },
  { value: "casual_wear", label: "Casual Wear" },
  { value: "kids_wear", label: "Kids Wear" },
  { value: "party_dress", label: "Party Dress" },
  { value: "evening_gown", label: "Evening Gown" },
];

// Female measurement fields for the form
const femaleMeasurementFields = [
  { name: "shoulder", label: "Shoulder" },
  { name: "chestBack", label: "Chest Back" },
  { name: "chestFront", label: "Chest Front" },
  { name: "bust", label: "Bust" },
  { name: "bustPoint", label: "Bust Point" },
  { name: "bustDistance", label: "Bust Distance" },
  { name: "empireCircum", label: "Empire Circum." },
  { name: "figure", label: "Figure" },
  { name: "waist", label: "Waist" },
  { name: "hip1", label: "Hip 1" },
  { name: "hip2", label: "Hip 2" },
  { name: "armHole", label: "Arm Hole" },
  { name: "sleeveLength", label: "Sleeve Length" },
  { name: "armAround", label: "Arm Around" },
  { name: "dressLength", label: "Dress Length" },
  { name: "blouseLength", label: "Blouse Length" },
  { name: "skirtLength", label: "Skirt Length" },
  { name: "depthNeck", label: "Depth Neck" },
  { name: "neckCircum", label: "Neck Circum." },
  { name: "pantsLength", label: "Pants Length" },
  { name: "crotch", label: "Crotch" },
  { name: "thigh", label: "Thigh" },
  { name: "knee", label: "Knee" },
  { name: "bottom", label: "Bottom" },
  { name: "belt", label: "Belt" },
];

// Male measurement fields for the form
const maleMeasurementFields = [
  { name: "shoulder", label: "Shoulder" },
  { name: "chestFront", label: "Chest Front" },
  { name: "bust", label: "Bust" },
  { name: "figure", label: "Figure" },
  { name: "waist", label: "Waist" },
  { name: "hip1", label: "Hip 1" },
  { name: "hip2", label: "Hip 2" },
  { name: "armHole", label: "Arm Hole" },
  { name: "sleeveLength", label: "Sleeve Length" },
  { name: "armAround", label: "Arm Around" },
  { name: "barongLength", label: "Barong Length" },
  { name: "neckCircum", label: "Neck Circum." },
  { name: "pantsLength", label: "Pants Length" },
  { name: "crotch", label: "Crotch" },
  { name: "thigh", label: "Thigh" },
  { name: "knee", label: "Knee" },
  { name: "bottom", label: "Bottom" },
  { name: "belt", label: "Belt" },
];

// ============================================
// MAIN COMPONENT
// ============================================

export default function Fitting() {
  // ============================================
  // STATE AND HOOKS
  // ============================================
  
  const [activeTab, setActiveTab] = useState("individual");
  const { toast } = useToast();

  // Data fetching
  const { data: fittings, isLoading } = useQuery({
    queryKey: ["/api/fittings"],
  });

  // Form setup with default values
  const form = useForm<FittingFormData>({
    resolver: zodResolver(fittingSchema),
    defaultValues: {
      fittingType: "individual",
      bookingDate: new Date(),
      totalAmount: "",
      depositAmount: "",
      category: "first_use",
      customers: [{
        name: "",
        phone: "",
        address: "",
        gender: "female",
        silhouette: "filipiniana",
        measurements: {
          shoulder: "",
          chestBack: "",
          chestFront: "",
          bust: "",
          bustPoint: "",
          bustDistance: "",
          empireCircum: "",
          figure: "",
          waist: "",
          hip1: "",
          hip2: "",
          armHole: "",
          sleeveLength: "",
          armAround: "",
          dressLength: "",
          blouseLength: "",
          skirtLength: "",
          depthNeck: "",
          neckCircum: "",
          pantsLength: "",
          crotch: "",
          thigh: "",
          knee: "",
          bottom: "",
          belt: "",
        },
      }],
    },
  });

  // Dynamic customer array management for group fittings
  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "customers",
  });

  // Watch form values for real-time updates
  const watchedFittingType = form.watch("fittingType");
  const watchedCustomers = form.watch("customers");
  const watchedTotalAmount = form.watch("totalAmount");
  const watchedDepositAmount = form.watch("depositAmount");
  
  // ============================================
  // UTILITY FUNCTIONS
  // ============================================
  
  // Calculate balance automatically (Total - Deposit = Balance)
  const calculateBalance = () => {
    const total = parseFloat(watchedTotalAmount || "0");
    const deposit = parseFloat(watchedDepositAmount || "0");
    return (total - deposit).toFixed(2);
  };

  // Add new customer to group fitting
  const addCustomer = () => {
    append({
      name: "",
      phone: "",
      address: "",
      gender: "female",
      silhouette: "filipiniana", 
      measurements: {
        shoulder: "",
        chestBack: "",
        chestFront: "",
        bust: "",
        bustPoint: "",
        bustDistance: "",
        empireCircum: "",
        figure: "",
        waist: "",
        hip1: "",
        hip2: "",
        armHole: "",
        sleeveLength: "",
        armAround: "",
        dressLength: "",
        blouseLength: "",
        skirtLength: "",
        depthNeck: "",
        neckCircum: "",
        pantsLength: "",
        crotch: "",
        thigh: "",
        knee: "",
        bottom: "",
        belt: "",
      },
    });
  };

  // ============================================
  // API CALLS AND MUTATIONS
  // ============================================
  
  // Create fitting mutation
  const createFittingMutation = useMutation({
    mutationFn: async (fittingData: any) => {
      const response = await apiRequest("POST", "/api/fittings", fittingData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/fittings"] });
      form.reset();
      toast({
        title: "Fitting appointment created",
        description: "Fitting has been scheduled successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create fitting appointment.",
        variant: "destructive",
      });
    },
  });

  // Handle form submission
  const onSubmit = async (data: FittingFormData) => {
    try {
      const totalAmount = parseFloat(data.totalAmount);
      const depositAmount = parseFloat(data.depositAmount || "0");
      const balance = totalAmount - depositAmount;

      await createFittingMutation.mutateAsync({
        fittingType: data.fittingType,
        bookingDate: data.bookingDate.toISOString(),
        firstFittingDate: data.firstFittingDate?.toISOString() || null,
        lastFittingDate: data.lastFittingDate?.toISOString() || null,
        pickupDate: data.pickupDate?.toISOString() || null,
        totalAmount: data.totalAmount,
        depositAmount: data.depositAmount || "0",
        balance: balance.toString(),
        asOfDate: data.asOfDate?.toISOString() || null,
        category: data.category,
        customers: data.customers,
        isWalkIn: true,
      });
    } catch (error) {
      console.error("Error creating fitting:", error);
    }
  };

  // ============================================
  // LOADING STATE
  // ============================================
  
  if (isLoading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-48"></div>
          <div className="h-96 bg-gray-200 rounded-xl"></div>
        </div>
      </div>
    );
  }

  // ============================================
  // MAIN RENDER - PAGE LAYOUT
  // ============================================
  
  return (
    <div className="p-6 space-y-6">
      {/* PAGE HEADER - Title and description */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Fitting</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Manage individual and group fittings
          </p>
        </div>
      </div>

      {/* TAB NAVIGATION - Individual vs Group fitting selector */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="individual">Individual Fitting</TabsTrigger>
          <TabsTrigger value="group">Group Fitting (Entourage)</TabsTrigger>
        </TabsList>

        {/* ============================================ */}
        {/* INDIVIDUAL FITTING TAB CONTENT */}
        {/* ============================================ */}
        <TabsContent value="individual" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <User className="w-5 h-5 mr-2" />
                New Individual Fitting
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  {/* Hidden field to set fitting type */}
                  <FormField
                    control={form.control}
                    name="fittingType"
                    render={({ field }) => (
                      <FormItem className="hidden">
                        <FormControl>
                          <Input {...field} value="individual" />
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  {/* DATE SECTION - Booking date, first fitting, last fitting, pickup date */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <FormField
                      control={form.control}
                      name="bookingDate"
                      render={({ field }) => (
                        <FormItem className="flex flex-col">
                          <FormLabel>Booking Date:</FormLabel>
                          <Popover>
                            <PopoverTrigger asChild>
                              <FormControl>
                                <Button variant={"outline"} className={cn("w-full pl-3 text-left font-normal", !field.value && "text-muted-foreground")}>
                                  {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                                  <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                </Button>
                              </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus />
                            </PopoverContent>
                          </Popover>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="firstFittingDate"
                      render={({ field }) => (
                        <FormItem className="flex flex-col">
                          <FormLabel>First Fitting:</FormLabel>
                          <Popover>
                            <PopoverTrigger asChild>
                              <FormControl>
                                <Button variant={"outline"} className={cn("w-full pl-3 text-left font-normal", !field.value && "text-muted-foreground")}>
                                  {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                                  <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                </Button>
                              </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus />
                            </PopoverContent>
                          </Popover>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="lastFittingDate"
                      render={({ field }) => (
                        <FormItem className="flex flex-col">
                          <FormLabel>Last Fitting:</FormLabel>
                          <Popover>
                            <PopoverTrigger asChild>
                              <FormControl>
                                <Button variant={"outline"} className={cn("w-full pl-3 text-left font-normal", !field.value && "text-muted-foreground")}>
                                  {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                                  <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                </Button>
                              </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus />
                            </PopoverContent>
                          </Popover>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="pickupDate"
                      render={({ field }) => (
                        <FormItem className="flex flex-col">
                          <FormLabel>Pickup Date:</FormLabel>
                          <Popover>
                            <PopoverTrigger asChild>
                              <FormControl>
                                <Button variant={"outline"} className={cn("w-full pl-3 text-left font-normal", !field.value && "text-muted-foreground")}>
                                  {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                                  <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                </Button>
                              </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus />
                            </PopoverContent>
                          </Popover>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  {/* FINANCIAL SECTION - Total amount, deposit, as of date, and auto-calculated balance */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <FormField
                      control={form.control}
                      name="totalAmount"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Total Amount:</FormLabel>
                          <FormControl>
                            <Input placeholder="0.00" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="depositAmount"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Amount Deposit:</FormLabel>
                          <FormControl>
                            <Input placeholder="0.00" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="asOfDate"
                      render={({ field }) => (
                        <FormItem className="flex flex-col">
                          <FormLabel>As of:</FormLabel>
                          <Popover>
                            <PopoverTrigger asChild>
                              <FormControl>
                                <Button variant={"outline"} className={cn("w-full pl-3 text-left font-normal", !field.value && "text-muted-foreground")}>
                                  {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                                  <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                </Button>
                              </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus />
                            </PopoverContent>
                          </Popover>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* AUTO-CALCULATED BALANCE - Updates automatically when total or deposit changes */}
                    <div>
                      <Label>Balance:</Label>
                      <div className="h-10 px-3 py-2 border rounded-md bg-muted text-muted-foreground font-medium">
                        ₱{calculateBalance()}
                      </div>
                    </div>
                  </div>

                  {/* CATEGORY SECTION - First use, to own, to rent, modified */}
                  <FormField
                    control={form.control}
                    name="category"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Category:</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="w-64">
                              <SelectValue placeholder="Select category" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="first_use">First Use?</SelectItem>
                            <SelectItem value="to_own">To Own?</SelectItem>
                            <SelectItem value="to_rent">To Rent?</SelectItem>
                            <SelectItem value="modified">Modified?</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* CUSTOMER INFORMATION SECTION - Name, contact, address, gender, silhouette, measurements */}
                  {fields.map((customer, customerIndex) => (
                    <Card key={customer.id} className="p-4">
                      <div className="space-y-4">
                        <h3 className="text-lg font-medium">Customer Information</h3>
                        
                        {/* CUSTOMER BASIC INFO - Name, phone, address */}
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <FormField
                            control={form.control}
                            name={`customers.${customerIndex}.name`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Name: *</FormLabel>
                                <FormControl>
                                  <Input placeholder="Full name" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name={`customers.${customerIndex}.phone`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Contact No: *</FormLabel>
                                <FormControl>
                                  <Input placeholder="+63 XXX XXX XXXX" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name={`customers.${customerIndex}.address`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Address:</FormLabel>
                                <FormControl>
                                  <Input placeholder="Complete address" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        {/* GENDER AND SILHOUETTE SELECTION - Updates measurement fields based on gender */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name={`customers.${customerIndex}.gender`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Gender:</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select gender" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="female">Female</SelectItem>
                                    <SelectItem value="male">Male</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name={`customers.${customerIndex}.silhouette`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Silhouette:</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select silhouette" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    {silhouetteOptions.map((option) => (
                                      <SelectItem key={option.value} value={option.value}>
                                        {option.label}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        {/* MEASUREMENTS SECTION - Gender-responsive measurement fields */}
                        <div>
                          <h4 className="text-md font-medium mb-3">
                            {watchedCustomers[customerIndex]?.gender === 'female' ? 'Female' : 'Male'} Measurements:
                          </h4>
                          {/* Grid of measurement input fields - changes based on gender selection */}
                          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
                            {(watchedCustomers[customerIndex]?.gender === 'female' ? femaleMeasurementFields : maleMeasurementFields).map((measurement) => (
                              <FormField
                                key={measurement.name}
                                control={form.control}
                                name={`customers.${customerIndex}.measurements.${measurement.name}` as any}
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel className="text-xs">{measurement.label}:</FormLabel>
                                    <FormControl>
                                      <Input placeholder="0" {...field} className="h-8 text-sm" />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            ))}
                          </div>
                        </div>
                      </div>
                    </Card>
                  ))}

                  {/* SUBMIT BUTTON - Create individual fitting */}
                  <Button type="submit" className="w-full" disabled={createFittingMutation.isPending}>
                    {createFittingMutation.isPending ? "Creating..." : "Create Individual Fitting"}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ============================================ */}
        {/* GROUP FITTING TAB CONTENT */}
        {/* ============================================ */}
        <TabsContent value="group" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Users className="w-5 h-5 mr-2" />
                New Group Fitting (Entourage)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  {/* Hidden field to set fitting type */}
                  <FormField
                    control={form.control}
                    name="fittingType"
                    render={({ field }) => (
                      <FormItem className="hidden">
                        <FormControl>
                          <Input {...field} value="group" />
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  {/* GROUP PACKAGE INFORMATION - Shared financial and date info for the entire group */}
                  <div className="bg-muted/50 p-4 rounded-lg">
                    <h3 className="text-lg font-medium mb-4">Group Entourage Package</h3>
                    
                    {/* GROUP DATES SECTION - Same date fields as individual but for the group */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                      <FormField
                        control={form.control}
                        name="bookingDate"
                        render={({ field }) => (
                          <FormItem className="flex flex-col">
                            <FormLabel>Booking Date:</FormLabel>
                            <Popover>
                              <PopoverTrigger asChild>
                                <FormControl>
                                  <Button variant={"outline"} className={cn("w-full pl-3 text-left font-normal", !field.value && "text-muted-foreground")}>
                                    {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                                    <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                  </Button>
                                </FormControl>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-0" align="start">
                                <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus />
                              </PopoverContent>
                            </Popover>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="firstFittingDate"
                        render={({ field }) => (
                          <FormItem className="flex flex-col">
                            <FormLabel>First Fitting:</FormLabel>
                            <Popover>
                              <PopoverTrigger asChild>
                                <FormControl>
                                  <Button variant={"outline"} className={cn("w-full pl-3 text-left font-normal", !field.value && "text-muted-foreground")}>
                                    {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                                    <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                  </Button>
                                </FormControl>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-0" align="start">
                                <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus />
                              </PopoverContent>
                            </Popover>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="lastFittingDate"
                        render={({ field }) => (
                          <FormItem className="flex flex-col">
                            <FormLabel>Last Fitting:</FormLabel>
                            <Popover>
                              <PopoverTrigger asChild>
                                <FormControl>
                                  <Button variant={"outline"} className={cn("w-full pl-3 text-left font-normal", !field.value && "text-muted-foreground")}>
                                    {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                                    <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                  </Button>
                                </FormControl>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-0" align="start">
                                <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus />
                              </PopoverContent>
                            </Popover>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="pickupDate"
                        render={({ field }) => (
                          <FormItem className="flex flex-col">
                            <FormLabel>Pickup Date:</FormLabel>
                            <Popover>
                              <PopoverTrigger asChild>
                                <FormControl>
                                  <Button variant={"outline"} className={cn("w-full pl-3 text-left font-normal", !field.value && "text-muted-foreground")}>
                                    {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                                    <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                  </Button>
                                </FormControl>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-0" align="start">
                                <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus />
                              </PopoverContent>
                            </Popover>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    {/* GROUP FINANCIAL SECTION - Package pricing instead of individual pricing */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <FormField
                        control={form.control}
                        name="totalAmount"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Total Package Amount:</FormLabel>
                            <FormControl>
                              <Input placeholder="0.00" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="depositAmount"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Package Deposit:</FormLabel>
                            <FormControl>
                              <Input placeholder="0.00" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="asOfDate"
                        render={({ field }) => (
                          <FormItem className="flex flex-col">
                            <FormLabel>As of:</FormLabel>
                            <Popover>
                              <PopoverTrigger asChild>
                                <FormControl>
                                  <Button variant={"outline"} className={cn("w-full pl-3 text-left font-normal", !field.value && "text-muted-foreground")}>
                                    {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                                    <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                  </Button>
                                </FormControl>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-0" align="start">
                                <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus />
                              </PopoverContent>
                            </Popover>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* AUTO-CALCULATED PACKAGE BALANCE */}
                      <div>
                        <Label>Package Balance:</Label>
                        <div className="h-10 px-3 py-2 border rounded-md bg-muted text-muted-foreground font-medium">
                          ₱{calculateBalance()}
                        </div>
                      </div>
                    </div>

                    {/* GROUP CATEGORY SECTION */}
                    <div className="mt-4">
                      <FormField
                        control={form.control}
                        name="category"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Category:</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger className="w-64">
                                  <SelectValue placeholder="Select category" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="first_use">First Use?</SelectItem>
                                <SelectItem value="to_own">To Own?</SelectItem>
                                <SelectItem value="to_rent">To Rent?</SelectItem>
                                <SelectItem value="modified">Modified?</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>

                  {/* INDIVIDUAL CUSTOMER CARDS - Each person in the group has their own card */}
                  {fields.map((customer, customerIndex) => (
                    <Card key={customer.id} className="p-4">
                      {/* CUSTOMER CARD HEADER - Customer number and remove button */}
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-medium">Customer {customerIndex + 1}</h3>
                        {customerIndex > 0 && (
                          <Button
                            type="button"
                            variant="destructive"
                            size="sm"
                            onClick={() => remove(customerIndex)}
                          >
                            <Trash2 className="w-4 h-4 mr-2" />
                            Remove
                          </Button>
                        )}
                      </div>
                      
                      <div className="space-y-4">
                        {/* CUSTOMER BASIC INFO - Name required, phone required, address optional for group */}
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <FormField
                            control={form.control}
                            name={`customers.${customerIndex}.name`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Name: *</FormLabel>
                                <FormControl>
                                  <Input placeholder="Full name" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name={`customers.${customerIndex}.phone`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Contact No: *</FormLabel>
                                <FormControl>
                                  <Input placeholder="+63 XXX XXX XXXX" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name={`customers.${customerIndex}.address`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Address: (Optional)</FormLabel>
                                <FormControl>
                                  <Input placeholder="Complete address" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        {/* GENDER AND SILHOUETTE - Same as individual */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name={`customers.${customerIndex}.gender`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Gender:</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select gender" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="female">Female</SelectItem>
                                    <SelectItem value="male">Male</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name={`customers.${customerIndex}.silhouette`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Silhouette:</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select silhouette" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    {silhouetteOptions.map((option) => (
                                      <SelectItem key={option.value} value={option.value}>
                                        {option.label}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        {/* CUSTOMER MEASUREMENTS - Gender-responsive, always required even in group */}
                        <div>
                          <h4 className="text-md font-medium mb-3">
                            {watchedCustomers[customerIndex]?.gender === 'female' ? 'Female' : 'Male'} Measurements:
                          </h4>
                          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
                            {(watchedCustomers[customerIndex]?.gender === 'female' ? femaleMeasurementFields : maleMeasurementFields).map((measurement) => (
                              <FormField
                                key={measurement.name}
                                control={form.control}
                                name={`customers.${customerIndex}.measurements.${measurement.name}` as any}
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel className="text-xs">{measurement.label}:</FormLabel>
                                    <FormControl>
                                      <Input placeholder="0" {...field} className="h-8 text-sm" />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            ))}
                          </div>
                        </div>
                      </div>
                    </Card>
                  ))}

                  {/* ADD MORE CUSTOMER BUTTON - For adding additional people to the group */}
                  <Button type="button" variant="outline" onClick={addCustomer} className="w-full">
                    <Plus className="w-4 h-4 mr-2" />
                    Add More Customer to Group
                  </Button>

                  {/* SUBMIT BUTTON - Create group fitting */}
                  <Button type="submit" className="w-full" disabled={createFittingMutation.isPending}>
                    {createFittingMutation.isPending ? "Creating..." : "Create Group Fitting (Entourage)"}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}