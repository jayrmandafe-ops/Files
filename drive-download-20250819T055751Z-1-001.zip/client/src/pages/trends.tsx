import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, TrendingDown, Star } from "lucide-react";

export default function Trends() {
  const { data: feedback, isLoading } = useQuery({
    queryKey: ["/api/feedback"],
  });

  const { data: garments } = useQuery({
    queryKey: ["/api/garments"],
  });

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-48"></div>
          <div className="h-96 bg-gray-200 rounded-xl"></div>
        </div>
      </div>
    );
  }

  // Calculate trend metrics
  const categoryTrends = garments?.reduce((acc: any, garment: any) => {
    acc[garment.category] = (acc[garment.category] || 0) + 1;
    return acc;
  }, {}) || {};

  const fabricTrends = garments?.reduce((acc: any, garment: any) => {
    if (garment.fabricUsed) {
      acc[garment.fabricUsed] = (acc[garment.fabricUsed] || 0) + 1;
    }
    return acc;
  }, {}) || {};

  const avgRating = feedback?.length > 0 
    ? feedback.reduce((sum: number, f: any) => sum + f.rating, 0) / feedback.length 
    : 0;

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Trends</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Analysis of popular garments and customer preferences
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Rating</CardTitle>
            <Star className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{avgRating.toFixed(1)}</div>
            <p className="text-xs text-muted-foreground">
              Based on {feedback?.length || 0} reviews
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Liked Garments</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {feedback?.filter((f: any) => f.liked).length || 0}
            </div>
            <p className="text-xs text-muted-foreground">
              Customer favorites
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Garments</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{garments?.length || 0}</div>
            <p className="text-xs text-muted-foreground">
              In inventory
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Categories</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{Object.keys(categoryTrends).length}</div>
            <p className="text-xs text-muted-foreground">
              Different types
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Popular Categories</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {Object.entries(categoryTrends)
                .sort(([,a], [,b]) => (b as number) - (a as number))
                .slice(0, 5)
                .map(([category, count]) => (
                  <div key={category} className="flex items-center justify-between">
                    <span className="text-sm font-medium">{category}</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-20 bg-muted rounded-full h-2">
                        <div 
                          className="bg-primary h-2 rounded-full" 
                          style={{ width: `${(count as number) * 20}%` }}
                        ></div>
                      </div>
                      <span className="text-sm text-muted-foreground">{count as number}</span>
                    </div>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Fabric Preferences</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {Object.entries(fabricTrends)
                .sort(([,a], [,b]) => (b as number) - (a as number))
                .slice(0, 5)
                .map(([fabric, count]) => (
                  <div key={fabric} className="flex items-center justify-between">
                    <span className="text-sm font-medium">{fabric}</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-20 bg-muted rounded-full h-2">
                        <div 
                          className="bg-chart-2 h-2 rounded-full" 
                          style={{ width: `${(count as number) * 25}%` }}
                        ></div>
                      </div>
                      <span className="text-sm text-muted-foreground">{count as number}</span>
                    </div>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Customer Feedback</CardTitle>
        </CardHeader>
        <CardContent>
          {feedback?.length > 0 ? (
            <div className="space-y-4">
              {feedback.slice(0, 5).map((item: any) => (
                <div key={item.id} className="flex items-start space-x-3 p-3 border border-border rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      <div className="flex items-center">
                        {[...Array(5)].map((_, i) => (
                          <Star 
                            key={i} 
                            className={`w-4 h-4 ${i < item.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} 
                          />
                        ))}
                      </div>
                      <span className="text-sm text-muted-foreground">
                        {item.rating}/5
                      </span>
                      {item.liked && (
                        <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">
                          Liked
                        </span>
                      )}
                    </div>
                    {item.review && (
                      <p className="text-sm text-foreground">{item.review}</p>
                    )}
                    <p className="text-xs text-muted-foreground mt-1">
                      Customer ID: {item.customerId.slice(0, 8)} • {new Date(item.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Star className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">No feedback available</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
