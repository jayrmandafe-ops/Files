import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, Mail, Phone, Grid3X3, List } from "lucide-react";
import { useState } from "react";

export default function Customers() {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  
  const { data: customers, isLoading } = useQuery({
    queryKey: ["/api/customers"],
  });

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-48"></div>
          <div className="h-96 bg-gray-200 rounded-xl"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-foreground">Customers</h1>
        
        <div className="flex items-center space-x-2">
          <Button
            variant={viewMode === 'grid' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setViewMode('grid')}
          >
            <Grid3X3 className="w-4 h-4 mr-2" />
            Grid
          </Button>
          <Button
            variant={viewMode === 'list' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setViewMode('list')}
          >
            <List className="w-4 h-4 mr-2" />
            List
          </Button>
        </div>
      </div>
      
      <div className={viewMode === 'grid' 
        ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4"
        : "space-y-3"
      }>
        {customers && Array.isArray(customers) && customers.length > 0 ? (
          customers.map((customer: any) => (
            viewMode === 'grid' ? (
              <Card key={customer.id} className="hover:shadow-md transition-shadow cursor-pointer">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3 mb-3">
                    <div className="w-10 h-10 bg-primary/10 text-primary rounded-full flex items-center justify-center font-semibold">
                      {customer.name.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <p className="font-medium">{customer.name}</p>
                      <p className="text-xs text-muted-foreground">
                        ID: {customer.id.slice(-8)}
                      </p>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    {customer.email && (
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Mail className="w-4 h-4 mr-2 flex-shrink-0" />
                        <span className="truncate">{customer.email}</span>
                      </div>
                    )}
                    {customer.phone && (
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Phone className="w-4 h-4 mr-2 flex-shrink-0" />
                        <span>{customer.phone}</span>
                      </div>
                    )}
                    {customer.address && (
                      <p className="text-sm text-muted-foreground line-clamp-2">
                        {customer.address}
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card key={customer.id} className="hover:shadow-md transition-shadow cursor-pointer">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-primary/10 text-primary rounded-full flex items-center justify-center font-semibold">
                      {customer.name.charAt(0).toUpperCase()}
                    </div>
                    
                    <div className="flex-1 grid grid-cols-1 md:grid-cols-4 gap-4">
                      <div>
                        <p className="font-medium">{customer.name}</p>
                        <p className="text-xs text-muted-foreground">
                          ID: {customer.id.slice(-8)}
                        </p>
                      </div>
                      
                      <div className="flex items-center text-sm text-muted-foreground">
                        {customer.email ? (
                          <>
                            <Mail className="w-4 h-4 mr-2 flex-shrink-0" />
                            <span className="truncate">{customer.email}</span>
                          </>
                        ) : (
                          <span className="text-muted-foreground/50">No email</span>
                        )}
                      </div>
                      
                      <div className="flex items-center text-sm text-muted-foreground">
                        {customer.phone ? (
                          <>
                            <Phone className="w-4 h-4 mr-2 flex-shrink-0" />
                            <span>{customer.phone}</span>
                          </>
                        ) : (
                          <span className="text-muted-foreground/50">No phone</span>
                        )}
                      </div>
                      
                      <div className="text-sm text-muted-foreground">
                        {customer.address ? (
                          <span className="line-clamp-1">{customer.address}</span>
                        ) : (
                          <span className="text-muted-foreground/50">No address</span>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          ))
        ) : (
          <div className="col-span-full text-center py-12">
            <Users className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">No customers found</p>
          </div>
        )}
      </div>
    </div>
  );
}