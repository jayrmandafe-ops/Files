import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { GripVertical, Move, Settings2, Eye, EyeOff, Palette, Globe, Shield, Bell, Save, RotateCcw } from "lucide-react";

interface DashboardWidget {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
  position: number;
}

export default function Settings() {
  const { toast } = useToast();
  const [hasChanges, setHasChanges] = useState(false);
  const [draggedOver, setDraggedOver] = useState<string | null>(null);

  // Load settings from localStorage
  const loadSettings = () => {
    const savedWidgets = localStorage.getItem("dashboard-widgets");
    const savedSettings = localStorage.getItem("app-settings");
    
    return {
      widgets: savedWidgets ? JSON.parse(savedWidgets) : [
        { id: "metrics", name: "Metrics Cards", description: "Gross revenue, avg order value, conversion rate, customers", enabled: true, position: 1 },
        { id: "sales-chart", name: "Sales Chart", description: "Sales over time visualization", enabled: true, position: 2 },
        { id: "top-garments", name: "Top Garments", description: "Best performing garments by sales", enabled: true, position: 3 },
        { id: "recent-orders", name: "Recent Orders", description: "Latest customer orders and status", enabled: true, position: 4 },
        { id: "upcoming-schedule", name: "Upcoming Schedule", description: "Fittings, pickups, and returns", enabled: true, position: 5 }
      ],
      settings: savedSettings ? JSON.parse(savedSettings) : {
        currency: "PHP",
        measurementUnit: "cm",
        dateFormat: "MM/DD/YYYY",
        timeFormat: "12h",
        language: "en",
        autoRefresh: true,
        showComparison: true,
        compactView: true,
        darkMode: false
      }
    };
  };

  const { widgets: initialWidgets, settings: initialSettings } = loadSettings();
  
  const [widgets, setWidgets] = useState<DashboardWidget[]>(initialWidgets);
  const [currency, setCurrency] = useState(initialSettings.currency);
  const [measurementUnit, setMeasurementUnit] = useState(initialSettings.measurementUnit);
  const [dateFormat, setDateFormat] = useState(initialSettings.dateFormat);
  const [timeFormat, setTimeFormat] = useState(initialSettings.timeFormat);
  const [language, setLanguage] = useState(initialSettings.language);
  const [autoRefresh, setAutoRefresh] = useState(initialSettings.autoRefresh);
  const [showComparison, setShowComparison] = useState(initialSettings.showComparison);
  const [compactView, setCompactView] = useState(initialSettings.compactView);
  const [darkMode, setDarkMode] = useState(initialSettings.darkMode);

  // Mark changes when any setting is modified (skip initial load)
  useEffect(() => {
    const timer = setTimeout(() => {
      setHasChanges(true);
    }, 100); // Small delay to skip initial load
    
    return () => clearTimeout(timer);
  }, [widgets, currency, measurementUnit, dateFormat, timeFormat, language, autoRefresh, showComparison, compactView, darkMode]);

  const handleDragStart = (e: React.DragEvent, widgetId: string) => {
    e.dataTransfer.setData("text/plain", widgetId);
    e.dataTransfer.effectAllowed = "move";
  };

  const handleDragOver = (e: React.DragEvent, targetId: string) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
    setDraggedOver(targetId);
  };

  const handleDragLeave = () => {
    setDraggedOver(null);
  };

  const handleDrop = (e: React.DragEvent, targetId: string) => {
    e.preventDefault();
    setDraggedOver(null);
    
    const draggedId = e.dataTransfer.getData("text/plain");
    if (draggedId === targetId) return;
    
    const newWidgets = [...widgets];
    const draggedIndex = newWidgets.findIndex(w => w.id === draggedId);
    const targetIndex = newWidgets.findIndex(w => w.id === targetId);
    
    if (draggedIndex !== -1 && targetIndex !== -1) {
      // Remove dragged item
      const [draggedWidget] = newWidgets.splice(draggedIndex, 1);
      // Insert at target position
      newWidgets.splice(targetIndex, 0, draggedWidget);
      
      // Update positions
      newWidgets.forEach((widget, index) => {
        widget.position = index + 1;
      });
      
      setWidgets(newWidgets);
    }
  };

  const toggleWidget = (widgetId: string) => {
    setWidgets(widgets.map(widget => 
      widget.id === widgetId 
        ? { ...widget, enabled: !widget.enabled }
        : widget
    ));
  };

  const resetWidgets = () => {
    const defaultWidgets = [
      { id: "metrics", name: "Metrics Cards", description: "Gross revenue, avg order value, conversion rate, customers", enabled: true, position: 1 },
      { id: "sales-chart", name: "Sales Chart", description: "Sales over time visualization", enabled: true, position: 2 },
      { id: "top-garments", name: "Top Garments", description: "Best performing garments by sales", enabled: true, position: 3 },
      { id: "recent-orders", name: "Recent Orders", description: "Latest customer orders and status", enabled: true, position: 4 },
      { id: "upcoming-schedule", name: "Upcoming Schedule", description: "Fittings, pickups, and returns", enabled: true, position: 5 }
    ];
    setWidgets(defaultWidgets);
  };

  const saveSettings = () => {
    // Save to localStorage
    localStorage.setItem("dashboard-widgets", JSON.stringify(widgets));
    localStorage.setItem("app-settings", JSON.stringify({
      currency,
      measurementUnit,
      dateFormat,
      timeFormat,
      language,
      autoRefresh,
      showComparison,
      compactView,
      darkMode
    }));
    
    setHasChanges(false);
    toast({
      title: "Settings saved",
      description: "Your preferences have been saved successfully.",
    });
  };

  const resetAllSettings = () => {
    // Reset widgets
    resetWidgets();
    
    // Reset other settings
    setCurrency("PHP");
    setMeasurementUnit("cm");
    setDateFormat("MM/DD/YYYY");
    setTimeFormat("12h");
    setLanguage("en");
    setAutoRefresh(true);
    setShowComparison(true);
    setCompactView(true);
    setDarkMode(false);
    
    // Clear localStorage
    localStorage.removeItem("dashboard-widgets");
    localStorage.removeItem("app-settings");
    
    setHasChanges(false);
    toast({
      title: "Settings reset",
      description: "All settings have been reset to defaults.",
    });
  };

  return (
    <div className="replit-container">
      <div className="replit-header">
        <div>
          <h1 className="replit-title">Settings</h1>
          <p className="replit-subtitle">Configure your dashboard and application preferences</p>
        </div>
        <div className="flex items-center space-x-2">
          {hasChanges && (
            <span className="text-xs text-amber-600 bg-amber-50 px-2 py-1 rounded">
              Unsaved changes
            </span>
          )}
          <Button 
            variant="outline" 
            size="sm" 
            onClick={resetAllSettings}
            className="text-xs"
          >
            <RotateCcw className="w-3 h-3 mr-1" />
            Reset All
          </Button>
          <Button 
            size="sm" 
            onClick={saveSettings}
            disabled={!hasChanges}
            className="text-xs"
          >
            <Save className="w-3 h-3 mr-1" />
            Save Changes
          </Button>
        </div>
      </div>

      <Tabs defaultValue="customization" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="customization" className="flex items-center text-xs">
            <Palette className="w-3 h-3 mr-1" />
            Customization
          </TabsTrigger>
          <TabsTrigger value="localization" className="flex items-center text-xs">
            <Globe className="w-3 h-3 mr-1" />
            Localization
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center text-xs">
            <Bell className="w-3 h-3 mr-1" />
            Notifications
          </TabsTrigger>
          <TabsTrigger value="security" className="flex items-center text-xs">
            <Shield className="w-3 h-3 mr-1" />
            Security
          </TabsTrigger>
        </TabsList>

        {/* Customization Tab */}
        <TabsContent value="customization" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Widget Configuration */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-sm">
                  <Settings2 className="w-4 h-4 mr-2" />
                  Widget Configuration
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  {widgets
                    .sort((a, b) => a.position - b.position)
                    .map((widget) => (
                    <div
                      key={widget.id}
                      draggable
                      onDragStart={(e) => handleDragStart(e, widget.id)}
                      onDragOver={(e) => handleDragOver(e, widget.id)}
                      onDragLeave={handleDragLeave}
                      onDrop={(e) => handleDrop(e, widget.id)}
                      className={`flex items-center justify-between p-3 border rounded-lg transition-all cursor-move hover:bg-muted/50 ${
                        draggedOver === widget.id ? 'border-blue-500 bg-blue-50' : ''
                      }`}
                    >
                      <div className="flex items-center space-x-3">
                        <GripVertical className="w-4 h-4 text-muted-foreground" />
                        <div className="flex items-center space-x-2">
                          {widget.enabled ? (
                            <Eye className="w-4 h-4 text-green-600" />
                          ) : (
                            <EyeOff className="w-4 h-4 text-muted-foreground" />
                          )}
                          <div>
                            <div className="text-sm font-medium">{widget.name}</div>
                            <div className="text-xs text-muted-foreground">{widget.description}</div>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <span className="text-xs text-muted-foreground">#{widget.position}</span>
                        <Switch
                          checked={widget.enabled}
                          onCheckedChange={() => toggleWidget(widget.id)}
                          className="scale-75"
                        />
                      </div>
                    </div>
                  ))}
                </div>
                <div className="text-xs text-muted-foreground bg-muted/30 p-2 rounded">
                  💡 Tip: Drag widgets to reorder them in your dashboard
                </div>
              </CardContent>
            </Card>

            {/* Layout Preview */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-sm">
                  <Move className="w-4 h-4 mr-2" />
                  Layout Preview
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="text-xs text-muted-foreground mb-3">
                    Drag widgets on the left to reorder them. Preview shows current layout order.
                  </div>
                  
                  {widgets
                    .filter(w => w.enabled)
                    .sort((a, b) => a.position - b.position)
                    .map((widget) => (
                    <div
                      key={widget.id}
                      className="flex items-center justify-between p-2 bg-muted/30 rounded text-xs"
                    >
                      <div className="font-medium">{widget.name}</div>
                      <div className="text-muted-foreground">Position {widget.position}</div>
                    </div>
                  ))}
                  
                  {widgets.filter(w => w.enabled).length === 0 && (
                    <div className="text-center py-8 text-muted-foreground text-xs">
                      No widgets enabled
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          <Separator />

          {/* Display Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Display Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm font-medium">Auto-refresh dashboard</Label>
                  <p className="text-xs text-muted-foreground">Automatically update metrics every 30 seconds</p>
                </div>
                <Switch 
                  checked={autoRefresh} 
                  onCheckedChange={setAutoRefresh}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm font-medium">Show comparison data</Label>
                  <p className="text-xs text-muted-foreground">Display percentage changes and trends</p>
                </div>
                <Switch 
                  checked={showComparison} 
                  onCheckedChange={setShowComparison}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm font-medium">Compact view</Label>
                  <p className="text-xs text-muted-foreground">Use smaller cards and tighter spacing</p>
                </div>
                <Switch 
                  checked={compactView} 
                  onCheckedChange={setCompactView}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm font-medium">Dark mode</Label>
                  <p className="text-xs text-muted-foreground">Switch between light and dark themes</p>
                </div>
                <Switch 
                  checked={darkMode} 
                  onCheckedChange={setDarkMode}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Localization Tab */}
        <TabsContent value="localization" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Regional Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Currency</Label>
                  <Select value={currency} onValueChange={setCurrency}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="PHP">Philippine Peso (₱)</SelectItem>
                      <SelectItem value="USD">US Dollar ($)</SelectItem>
                      <SelectItem value="EUR">Euro (€)</SelectItem>
                      <SelectItem value="GBP">British Pound (£)</SelectItem>
                      <SelectItem value="JPY">Japanese Yen (¥)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label className="text-sm font-medium">Measurement Unit</Label>
                  <Select value={measurementUnit} onValueChange={setMeasurementUnit}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cm">Centimeters (cm)</SelectItem>
                      <SelectItem value="inches">Inches (in)</SelectItem>
                      <SelectItem value="mm">Millimeters (mm)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label className="text-sm font-medium">Date Format</Label>
                  <Select value={dateFormat} onValueChange={setDateFormat}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="MM/DD/YYYY">MM/DD/YYYY</SelectItem>
                      <SelectItem value="DD/MM/YYYY">DD/MM/YYYY</SelectItem>
                      <SelectItem value="YYYY-MM-DD">YYYY-MM-DD</SelectItem>
                      <SelectItem value="DD MMM YYYY">DD MMM YYYY</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label className="text-sm font-medium">Time Format</Label>
                  <Select value={timeFormat} onValueChange={setTimeFormat}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="12h">12 Hour (AM/PM)</SelectItem>
                      <SelectItem value="24h">24 Hour</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-sm font-medium">Language</Label>
                <Select value={language} onValueChange={setLanguage}>
                  <SelectTrigger className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="en">English</SelectItem>
                    <SelectItem value="tl">Tagalog</SelectItem>
                    <SelectItem value="es">Spanish</SelectItem>
                    <SelectItem value="zh">Chinese</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-sm font-medium">Business Name</Label>
                <Input defaultValue="Kutur ni Jean" className="text-sm" />
              </div>

              <div className="space-y-2">
                <Label className="text-sm font-medium">Business Address</Label>
                <Input placeholder="Enter your business address" className="text-sm" />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notifications Tab */}
        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Notification Preferences</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm font-medium">New order notifications</Label>
                  <p className="text-xs text-muted-foreground">Get notified when new orders are placed</p>
                </div>
                <Switch defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm font-medium">Payment confirmations</Label>
                  <p className="text-xs text-muted-foreground">Receive alerts for successful payments</p>
                </div>
                <Switch defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm font-medium">Appointment reminders</Label>
                  <p className="text-xs text-muted-foreground">Reminders for fittings and pickups</p>
                </div>
                <Switch defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm font-medium">Low inventory alerts</Label>
                  <p className="text-xs text-muted-foreground">Alert when garment stock is low</p>
                </div>
                <Switch />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm font-medium">Weekly reports</Label>
                  <p className="text-xs text-muted-foreground">Receive weekly business summaries</p>
                </div>
                <Switch />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Security Tab */}
        <TabsContent value="security" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Security Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm font-medium">Two-factor authentication</Label>
                  <p className="text-xs text-muted-foreground">Add extra security to your account</p>
                </div>
                <Switch />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm font-medium">Auto logout</Label>
                  <p className="text-xs text-muted-foreground">Automatically logout after inactivity</p>
                </div>
                <Switch defaultChecked />
              </div>

              <div className="space-y-2">
                <Label className="text-sm font-medium">Session timeout</Label>
                <Select defaultValue="30">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="15">15 minutes</SelectItem>
                    <SelectItem value="30">30 minutes</SelectItem>
                    <SelectItem value="60">1 hour</SelectItem>
                    <SelectItem value="120">2 hours</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Separator />

              <div className="space-y-3">
                <h4 className="text-sm font-medium">Data Management</h4>
                <div className="space-y-2">
                  <Button variant="outline" size="sm" className="w-full justify-start">
                    Export Data
                  </Button>
                  <Button variant="outline" size="sm" className="w-full justify-start">
                    Import Backup
                  </Button>
                  <Button variant="destructive" size="sm" className="w-full justify-start">
                    Delete All Data
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}