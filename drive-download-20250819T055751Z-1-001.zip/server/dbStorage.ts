import { neon } from "@neondatabase/serverless";
import { IStorage } from "./storage.js";
import { 
  type Customer, type InsertCustomer,
  type Garment, type InsertGarment,
  type Order, type InsertOrder,
  type Schedule, type InsertSchedule,
  type Fitting, type InsertFitting,
  type Feedback, type InsertFeedback,
  type Sale, type InsertSale,
  type User, type InsertUser 
} from "@shared/schema";

const sql = neon(process.env.DATABASE_URL!);

export class DBStorage implements IStorage {
  // Dashboard analytics
  async getDashboardData() {
    try {
      // Get daily sales
      const dailySalesResult = await sql`
        SELECT COALESCE(SUM(amount), 0)::float as daily_sales
        FROM sales 
        WHERE DATE(transaction_date) = CURRENT_DATE
      `;
      const dailySales = dailySalesResult[0]?.daily_sales || 0;

      // Get daily customers (unique customers who made orders today)
      const dailyCustomersResult = await sql`
        SELECT COUNT(DISTINCT customer_id)::int as daily_customers
        FROM orders 
        WHERE DATE(created_at) = CURRENT_DATE
      `;
      const dailyCustomers = dailyCustomersResult[0]?.daily_customers || 0;

      // Get pending and completed orders
      const orderStatsResult = await sql`
        SELECT 
          COUNT(*) FILTER (WHERE status = 'pending')::int as pending_orders,
          COUNT(*) FILTER (WHERE status = 'completed')::int as completed_orders
        FROM orders
      `;
      const pendingOrders = orderStatsResult[0]?.pending_orders || 0;
      const completedOrders = orderStatsResult[0]?.completed_orders || 0;

      // Get sales data for chart (last 7 days)
      const salesDataResult = await sql`
        SELECT 
          DATE(transaction_date) as date,
          SUM(amount)::float as sales,
          COUNT(*)::int as orders
        FROM sales 
        WHERE transaction_date >= CURRENT_DATE - INTERVAL '7 days'
        GROUP BY DATE(transaction_date)
        ORDER BY date
      `;
      
      const salesData = salesDataResult.map(row => ({
        date: row.date,
        sales: row.sales || 0,
        orders: row.orders || 0
      }));

      // Get top garments by sales
      const topGarmentsResult = await sql`
        SELECT 
          g.name,
          COUNT(o.id)::int as sales,
          SUM(s.amount)::float as revenue
        FROM garments g
        JOIN orders o ON g.id = o.garment_id
        JOIN sales s ON o.id = s.order_id
        GROUP BY g.id, g.name
        ORDER BY revenue DESC
        LIMIT 4
      `;
      
      const topGarments = topGarmentsResult.map(row => ({
        name: row.name,
        sales: row.sales || 0,
        revenue: row.revenue || 0
      }));

      // Get recent orders
      const recentOrdersResult = await sql`
        SELECT 
          o.id,
          c.name as customer,
          g.name as garment,
          o.status,
          o.total_amount::float as amount,
          o.created_at::text as date
        FROM orders o
        JOIN customers c ON o.customer_id = c.id
        JOIN garments g ON o.garment_id = g.id
        ORDER BY o.created_at DESC
        LIMIT 5
      `;
      
      const recentOrders = recentOrdersResult.map(row => ({
        id: row.id,
        customer: row.customer,
        garment: row.garment,
        status: row.status,
        amount: parseFloat(row.amount),
        date: new Date(row.date).toISOString().split('T')[0]
      }));

      // Get upcoming schedule
      const upcomingScheduleResult = await sql`
        SELECT 
          s.id,
          s.type,
          c.name as customer,
          g.name as garment,
          TO_CHAR(s.scheduled_date, 'HH12:MI AM') as time,
          s.scheduled_date::text as date
        FROM schedules s
        JOIN customers c ON s.customer_id = c.id
        LEFT JOIN orders o ON s.order_id = o.id
        LEFT JOIN garments g ON o.garment_id = g.id
        WHERE s.scheduled_date >= NOW() AND s.status = 'scheduled'
        ORDER BY s.scheduled_date
        LIMIT 5
      `;
      
      const upcomingSchedule = upcomingScheduleResult.map(row => ({
        id: row.id,
        type: row.type,
        customer: row.customer,
        garment: row.garment || 'Consultation',
        time: row.time,
        date: new Date(row.date).toISOString().split('T')[0]
      }));

      return {
        dailySales,
        dailyCustomers,
        pendingOrders,
        completedOrders,
        salesData,
        topGarments,
        recentOrders,
        upcomingSchedule
      };
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
      // Return empty data instead of throwing
      return {
        dailySales: 0,
        dailyCustomers: 0,
        pendingOrders: 0,
        completedOrders: 0,
        salesData: [],
        topGarments: [],
        recentOrders: [],
        upcomingSchedule: []
      };
    }
  }

  // Customer methods
  async getCustomers(): Promise<Customer[]> {
    const result = await sql`
      SELECT 
        id,
        name,
        email,
        phone,
        address,
        date_of_birth as "dateOfBirth",
        notes,
        created_at as "createdAt"
      FROM customers 
      ORDER BY created_at DESC
    `;
    return result as Customer[];
  }

  async getCustomer(id: string): Promise<Customer | undefined> {
    const result = await sql`SELECT * FROM customers WHERE id = ${id}`;
    return result[0] as Customer | undefined;
  }

  async createCustomer(customer: InsertCustomer): Promise<Customer> {
    const result = await sql`
      INSERT INTO customers (name, email, phone, address, date_of_birth, notes)
      VALUES (${customer.name}, ${customer.email}, ${customer.phone}, ${customer.address}, ${customer.dateOfBirth}, ${customer.notes})
      RETURNING *
    `;
    return result[0] as Customer;
  }

  async updateCustomer(id: string, customer: Partial<InsertCustomer>): Promise<Customer> {
    const result = await sql`
      UPDATE customers 
      SET name = COALESCE(${customer.name}, name),
          email = COALESCE(${customer.email}, email),
          phone = COALESCE(${customer.phone}, phone),
          address = COALESCE(${customer.address}, address),
          date_of_birth = COALESCE(${customer.dateOfBirth}, date_of_birth),
          notes = COALESCE(${customer.notes}, notes)
      WHERE id = ${id}
      RETURNING *
    `;
    return result[0] as Customer;
  }

  async deleteCustomer(id: string): Promise<void> {
    await sql`DELETE FROM customers WHERE id = ${id}`;
  }

  // Orders methods
  async getOrders(): Promise<Order[]> {
    const result = await sql`
      SELECT 
        id,
        customer_id as "customerId",
        garment_id as "garmentId", 
        order_type as "orderType",
        status,
        total_amount as "totalAmount",
        deposit_amount as "depositAmount",
        balance_amount as "balanceAmount",
        rental_duration as "rentalDuration",
        pickup_date as "pickupDate",
        return_date as "returnDate",
        created_at as "createdAt"
      FROM orders 
      ORDER BY created_at DESC
    `;
    return result as Order[];
  }

  async getOrder(id: string): Promise<Order | undefined> {
    const result = await sql`SELECT * FROM orders WHERE id = ${id}`;
    return result[0] as Order | undefined;
  }

  async getOrdersByCustomer(customerId: string): Promise<Order[]> {
    const result = await sql`SELECT * FROM orders WHERE customer_id = ${customerId} ORDER BY created_at DESC`;
    return result as Order[];
  }

  async createOrder(order: InsertOrder): Promise<Order> {
    const result = await sql`
      INSERT INTO orders (customer_id, garment_id, order_type, status, total_amount, deposit_amount, balance_amount, rental_duration, pickup_date, return_date)
      VALUES (${order.customerId}, ${order.garmentId}, ${order.orderType}, ${order.status}, ${order.totalAmount}, ${order.depositAmount}, ${order.balanceAmount}, ${order.rentalDuration}, ${order.pickupDate}, ${order.returnDate})
      RETURNING *
    `;
    return result[0] as Order;
  }

  async updateOrder(id: string, order: Partial<InsertOrder>): Promise<Order> {
    const result = await sql`
      UPDATE orders 
      SET status = COALESCE(${order.status}, status),
          total_amount = COALESCE(${order.totalAmount}, total_amount),
          deposit_amount = COALESCE(${order.depositAmount}, deposit_amount),
          balance_amount = COALESCE(${order.balanceAmount}, balance_amount)
      WHERE id = ${id}
      RETURNING *
    `;
    return result[0] as Order;
  }

  async deleteOrder(id: string): Promise<void> {
    await sql`DELETE FROM orders WHERE id = ${id}`;
  }

  // Schedules methods  
  async getSchedules(): Promise<Schedule[]> {
    const result = await sql`
      SELECT 
        id,
        customer_id as "customerId",
        order_id as "orderId",
        type,
        scheduled_date as "scheduledDate",
        status,
        notes,
        created_at as "createdAt"
      FROM schedules 
      ORDER BY scheduled_date
    `;
    return result as Schedule[];
  }

  async getSchedule(id: string): Promise<Schedule | undefined> {
    const result = await sql`SELECT * FROM schedules WHERE id = ${id}`;
    return result[0] as Schedule | undefined;
  }

  async getSchedulesByCustomer(customerId: string): Promise<Schedule[]> {
    const result = await sql`SELECT * FROM schedules WHERE customer_id = ${customerId} ORDER BY scheduled_date`;
    return result as Schedule[];
  }

  async createSchedule(schedule: InsertSchedule): Promise<Schedule> {
    const result = await sql`
      INSERT INTO schedules (customer_id, order_id, type, scheduled_date, status, notes)
      VALUES (${schedule.customerId}, ${schedule.orderId}, ${schedule.type}, ${schedule.scheduledDate}, ${schedule.status}, ${schedule.notes})
      RETURNING *
    `;
    return result[0] as Schedule;
  }

  async updateSchedule(id: string, schedule: Partial<InsertSchedule>): Promise<Schedule> {
    const result = await sql`
      UPDATE schedules 
      SET status = COALESCE(${schedule.status}, status),
          notes = COALESCE(${schedule.notes}, notes)
      WHERE id = ${id}
      RETURNING *
    `;
    return result[0] as Schedule;
  }

  async deleteSchedule(id: string): Promise<void> {
    await sql`DELETE FROM schedules WHERE id = ${id}`;
  }

  // Stub implementations for other required methods
  async getUser(id: string): Promise<User | undefined> { return undefined; }
  async getUserByUsername(username: string): Promise<User | undefined> { return undefined; }
  async createUser(user: InsertUser): Promise<User> { throw new Error("Not implemented"); }

  async getGarments(): Promise<Garment[]> { 
    const result = await sql`SELECT * FROM garments WHERE is_archived = false ORDER BY created_at DESC`;
    return result as Garment[];
  }
  async getGarment(id: string): Promise<Garment | undefined> { 
    const result = await sql`SELECT * FROM garments WHERE id = ${id}`;
    return result[0] as Garment | undefined;
  }
  async createGarment(garment: InsertGarment): Promise<Garment> { throw new Error("Not implemented"); }
  async updateGarment(id: string, garment: Partial<InsertGarment>): Promise<Garment> { throw new Error("Not implemented"); }
  async deleteGarment(id: string): Promise<void> { throw new Error("Not implemented"); }

  async getFittings(): Promise<Fitting[]> { 
    const result = await sql`SELECT * FROM fittings ORDER BY created_at DESC`;
    return result as Fitting[];
  }
  async getFitting(id: string): Promise<Fitting | undefined> { return undefined; }
  async getFittingsByCustomer(customerId: string): Promise<Fitting[]> { return []; }
  async createFitting(fitting: InsertFitting): Promise<Fitting> { throw new Error("Not implemented"); }
  async updateFitting(id: string, fitting: Partial<InsertFitting>): Promise<Fitting> { throw new Error("Not implemented"); }
  async deleteFitting(id: string): Promise<void> { throw new Error("Not implemented"); }

  async getFeedbacks(): Promise<Feedback[]> { 
    const result = await sql`SELECT * FROM feedback ORDER BY created_at DESC`;
    return result as Feedback[];
  }
  async getFeedback(id: string): Promise<Feedback | undefined> { return undefined; }
  async getFeedbacksByCustomer(customerId: string): Promise<Feedback[]> { return []; }
  async getFeedbacksByGarment(garmentId: string): Promise<Feedback[]> { return []; }
  async createFeedback(feedback: InsertFeedback): Promise<Feedback> { throw new Error("Not implemented"); }
  async updateFeedback(id: string, feedback: Partial<InsertFeedback>): Promise<Feedback> { throw new Error("Not implemented"); }
  async deleteFeedback(id: string): Promise<void> { throw new Error("Not implemented"); }

  async getSales(): Promise<Sale[]> { 
    const result = await sql`SELECT * FROM sales ORDER BY transaction_date DESC`;
    return result as Sale[];
  }
  async getSale(id: string): Promise<Sale | undefined> { return undefined; }
  async getSalesByCustomer(customerId: string): Promise<Sale[]> { return []; }
  async getSalesByDateRange(startDate: Date, endDate: Date): Promise<Sale[]> { return []; }
  async createSale(sale: InsertSale): Promise<Sale> { throw new Error("Not implemented"); }
  async updateSale(id: string, sale: Partial<InsertSale>): Promise<Sale> { throw new Error("Not implemented"); }
  async deleteSale(id: string): Promise<void> { throw new Error("Not implemented"); }
}