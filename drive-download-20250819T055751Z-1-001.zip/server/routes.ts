import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertCustomerSchema,
  insertGarmentSchema, 
  insertOrderSchema,
  insertScheduleSchema,
  insertFittingSchema,
  insertFeedbackSchema,
  insertSaleSchema 
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Dashboard analytics
  app.get("/api/dashboard", async (req, res) => {
    try {
      const metrics = await storage.getDashboardData();
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard metrics" });
    }
  });

  // Customer routes
  app.get("/api/customers", async (req, res) => {
    try {
      const customers = await storage.getCustomers();
      res.json(customers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch customers" });
    }
  });

  app.get("/api/customers/:id", async (req, res) => {
    try {
      const customer = await storage.getCustomer(req.params.id);
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      res.json(customer);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch customer" });
    }
  });

  app.post("/api/customers", async (req, res) => {
    try {
      const customerData = insertCustomerSchema.parse(req.body);
      const customer = await storage.createCustomer(customerData);
      res.status(201).json(customer);
    } catch (error) {
      res.status(400).json({ message: "Invalid customer data" });
    }
  });

  app.patch("/api/customers/:id", async (req, res) => {
    try {
      const customerData = insertCustomerSchema.partial().parse(req.body);
      const customer = await storage.updateCustomer(req.params.id, customerData);
      res.json(customer);
    } catch (error) {
      res.status(400).json({ message: "Failed to update customer" });
    }
  });

  app.delete("/api/customers/:id", async (req, res) => {
    try {
      await storage.deleteCustomer(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete customer" });
    }
  });

  // Garment routes
  app.get("/api/garments", async (req, res) => {
    try {
      const garments = await storage.getGarments();
      res.json(garments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch garments" });
    }
  });

  app.get("/api/garments/:id", async (req, res) => {
    try {
      const garment = await storage.getGarment(req.params.id);
      if (!garment) {
        return res.status(404).json({ message: "Garment not found" });
      }
      res.json(garment);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch garment" });
    }
  });

  app.post("/api/garments", async (req, res) => {
    try {
      const garmentData = insertGarmentSchema.parse(req.body);
      const garment = await storage.createGarment(garmentData);
      res.status(201).json(garment);
    } catch (error) {
      res.status(400).json({ message: "Invalid garment data" });
    }
  });

  app.patch("/api/garments/:id", async (req, res) => {
    try {
      const garmentData = insertGarmentSchema.partial().parse(req.body);
      const garment = await storage.updateGarment(req.params.id, garmentData);
      res.json(garment);
    } catch (error) {
      res.status(400).json({ message: "Failed to update garment" });
    }
  });

  app.delete("/api/garments/:id", async (req, res) => {
    try {
      await storage.deleteGarment(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete garment" });
    }
  });

  // Order routes
  app.get("/api/orders", async (req, res) => {
    try {
      const { customerId } = req.query;
      if (customerId) {
        const orders = await storage.getOrdersByCustomer(customerId as string);
        res.json(orders);
      } else {
        const orders = await storage.getOrders();
        res.json(orders);
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });

  app.get("/api/orders/:id", async (req, res) => {
    try {
      const order = await storage.getOrder(req.params.id);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      res.json(order);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch order" });
    }
  });

  app.post("/api/orders", async (req, res) => {
    try {
      const orderData = insertOrderSchema.parse(req.body);
      const order = await storage.createOrder(orderData);
      res.status(201).json(order);
    } catch (error) {
      res.status(400).json({ message: "Invalid order data" });
    }
  });

  app.patch("/api/orders/:id", async (req, res) => {
    try {
      const orderData = insertOrderSchema.partial().parse(req.body);
      const order = await storage.updateOrder(req.params.id, orderData);
      res.json(order);
    } catch (error) {
      res.status(400).json({ message: "Failed to update order" });
    }
  });

  app.delete("/api/orders/:id", async (req, res) => {
    try {
      await storage.deleteOrder(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete order" });
    }
  });

  // Schedule routes
  app.get("/api/schedules", async (req, res) => {
    try {
      const { customerId } = req.query;
      if (customerId) {
        const schedules = await storage.getSchedulesByCustomer(customerId as string);
        res.json(schedules);
      } else {
        const schedules = await storage.getSchedules();
        res.json(schedules);
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch schedules" });
    }
  });

  app.post("/api/schedules", async (req, res) => {
    try {
      const scheduleData = insertScheduleSchema.parse(req.body);
      const schedule = await storage.createSchedule(scheduleData);
      res.status(201).json(schedule);
    } catch (error) {
      res.status(400).json({ message: "Invalid schedule data" });
    }
  });

  app.patch("/api/schedules/:id", async (req, res) => {
    try {
      const scheduleData = insertScheduleSchema.partial().parse(req.body);
      const schedule = await storage.updateSchedule(req.params.id, scheduleData);
      res.json(schedule);
    } catch (error) {
      res.status(400).json({ message: "Failed to update schedule" });
    }
  });

  app.delete("/api/schedules/:id", async (req, res) => {
    try {
      await storage.deleteSchedule(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete schedule" });
    }
  });

  // Fitting routes
  app.get("/api/fittings", async (req, res) => {
    try {
      const { customerId } = req.query;
      if (customerId) {
        const fittings = await storage.getFittingsByCustomer(customerId as string);
        res.json(fittings);
      } else {
        const fittings = await storage.getFittings();
        res.json(fittings);
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch fittings" });
    }
  });

  app.post("/api/fittings", async (req, res) => {
    try {
      const fittingData = insertFittingSchema.parse(req.body);
      const fitting = await storage.createFitting(fittingData);
      res.status(201).json(fitting);
    } catch (error) {
      res.status(400).json({ message: "Invalid fitting data" });
    }
  });

  app.patch("/api/fittings/:id", async (req, res) => {
    try {
      const fittingData = insertFittingSchema.partial().parse(req.body);
      const fitting = await storage.updateFitting(req.params.id, fittingData);
      res.json(fitting);
    } catch (error) {
      res.status(400).json({ message: "Failed to update fitting" });
    }
  });

  // Feedback routes
  app.get("/api/feedback", async (req, res) => {
    try {
      const { customerId, garmentId } = req.query;
      if (customerId) {
        const feedback = await storage.getFeedbacksByCustomer(customerId as string);
        res.json(feedback);
      } else if (garmentId) {
        const feedback = await storage.getFeedbacksByGarment(garmentId as string);
        res.json(feedback);
      } else {
        const feedback = await storage.getFeedbacks();
        res.json(feedback);
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch feedback" });
    }
  });

  app.post("/api/feedback", async (req, res) => {
    try {
      const feedbackData = insertFeedbackSchema.parse(req.body);
      const feedback = await storage.createFeedback(feedbackData);
      res.status(201).json(feedback);
    } catch (error) {
      res.status(400).json({ message: "Invalid feedback data" });
    }
  });

  // Sales routes
  app.get("/api/sales", async (req, res) => {
    try {
      const { customerId, startDate, endDate } = req.query;
      if (customerId) {
        const sales = await storage.getSalesByCustomer(customerId as string);
        res.json(sales);
      } else if (startDate && endDate) {
        const sales = await storage.getSalesByDateRange(new Date(startDate as string), new Date(endDate as string));
        res.json(sales);
      } else {
        const sales = await storage.getSales();
        res.json(sales);
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch sales" });
    }
  });

  app.post("/api/sales", async (req, res) => {
    try {
      const saleData = insertSaleSchema.parse(req.body);
      const sale = await storage.createSale(saleData);
      res.status(201).json(sale);
    } catch (error) {
      res.status(400).json({ message: "Invalid sale data" });
    }
  });

  app.patch("/api/sales/:id", async (req, res) => {
    try {
      const saleData = insertSaleSchema.partial().parse(req.body);
      const sale = await storage.updateSale(req.params.id, saleData);
      res.json(sale);
    } catch (error) {
      res.status(400).json({ message: "Failed to update sale" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
