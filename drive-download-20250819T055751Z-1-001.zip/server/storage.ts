import { 
  type Customer, type InsertCustomer,
  type Garment, type InsertGarment,
  type Order, type InsertOrder,
  type Schedule, type InsertSchedule,
  type Fitting, type InsertFitting,
  type Feedback, type InsertFeedback,
  type Sale, type InsertSale,
  type User, type InsertUser 
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Customer methods
  getCustomers(): Promise<Customer[]>;
  getCustomer(id: string): Promise<Customer | undefined>;
  createCustomer(customer: InsertCustomer): Promise<Customer>;
  updateCustomer(id: string, customer: Partial<InsertCustomer>): Promise<Customer>;
  deleteCustomer(id: string): Promise<void>;

  // Garment methods
  getGarments(): Promise<Garment[]>;
  getGarment(id: string): Promise<Garment | undefined>;
  createGarment(garment: InsertGarment): Promise<Garment>;
  updateGarment(id: string, garment: Partial<InsertGarment>): Promise<Garment>;
  deleteGarment(id: string): Promise<void>;

  // Order methods
  getOrders(): Promise<Order[]>;
  getOrder(id: string): Promise<Order | undefined>;
  getOrdersByCustomer(customerId: string): Promise<Order[]>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrder(id: string, order: Partial<InsertOrder>): Promise<Order>;
  deleteOrder(id: string): Promise<void>;

  // Schedule methods
  getSchedules(): Promise<Schedule[]>;
  getSchedule(id: string): Promise<Schedule | undefined>;
  getSchedulesByCustomer(customerId: string): Promise<Schedule[]>;
  createSchedule(schedule: InsertSchedule): Promise<Schedule>;
  updateSchedule(id: string, schedule: Partial<InsertSchedule>): Promise<Schedule>;
  deleteSchedule(id: string): Promise<void>;

  // Fitting methods
  getFittings(): Promise<Fitting[]>;
  getFitting(id: string): Promise<Fitting | undefined>;
  getFittingsByCustomer(customerId: string): Promise<Fitting[]>;
  createFitting(fitting: InsertFitting): Promise<Fitting>;
  updateFitting(id: string, fitting: Partial<InsertFitting>): Promise<Fitting>;
  deleteFitting(id: string): Promise<void>;

  // Feedback methods
  getFeedbacks(): Promise<Feedback[]>;
  getFeedback(id: string): Promise<Feedback | undefined>;
  getFeedbacksByCustomer(customerId: string): Promise<Feedback[]>;
  getFeedbacksByGarment(garmentId: string): Promise<Feedback[]>;
  createFeedback(feedback: InsertFeedback): Promise<Feedback>;
  updateFeedback(id: string, feedback: Partial<InsertFeedback>): Promise<Feedback>;
  deleteFeedback(id: string): Promise<void>;

  // Sales methods
  getSales(): Promise<Sale[]>;
  getSale(id: string): Promise<Sale | undefined>;
  getSalesByCustomer(customerId: string): Promise<Sale[]>;
  getSalesByDateRange(startDate: Date, endDate: Date): Promise<Sale[]>;
  createSale(sale: InsertSale): Promise<Sale>;
  updateSale(id: string, sale: Partial<InsertSale>): Promise<Sale>;
  deleteSale(id: string): Promise<void>;

  // Analytics methods
  getDashboardData(): Promise<{
    dailySales: number;
    dailyCustomers: number;
    pendingOrders: number;
    completedOrders: number;
    salesData: Array<{ date: string; sales: number; orders: number }>;
    topGarments: Array<{ name: string; sales: number; revenue: number }>;
    recentOrders: Array<{ id: string; customer: string; garment: string; status: string; amount: number; date: string }>;
    upcomingSchedule: Array<{ id: string; type: string; customer: string; garment: string; time: string; date: string }>;
  }>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private customers: Map<string, Customer>;
  private garments: Map<string, Garment>;
  private orders: Map<string, Order>;
  private schedules: Map<string, Schedule>;
  private fittings: Map<string, Fitting>;
  private feedbacks: Map<string, Feedback>;
  private sales: Map<string, Sale>;

  constructor() {
    this.users = new Map();
    this.customers = new Map();
    this.garments = new Map();
    this.orders = new Map();
    this.schedules = new Map();
    this.fittings = new Map();
    this.feedbacks = new Map();
    this.sales = new Map();
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Customer methods
  async getCustomers(): Promise<Customer[]> {
    return Array.from(this.customers.values());
  }

  async getCustomer(id: string): Promise<Customer | undefined> {
    return this.customers.get(id);
  }

  async createCustomer(insertCustomer: InsertCustomer): Promise<Customer> {
    const id = randomUUID();
    const customer: Customer = { 
      ...insertCustomer, 
      id,
      createdAt: new Date()
    };
    this.customers.set(id, customer);
    return customer;
  }

  async updateCustomer(id: string, customerUpdate: Partial<InsertCustomer>): Promise<Customer> {
    const existing = this.customers.get(id);
    if (!existing) throw new Error("Customer not found");
    
    const updated = { ...existing, ...customerUpdate };
    this.customers.set(id, updated);
    return updated;
  }

  async deleteCustomer(id: string): Promise<void> {
    this.customers.delete(id);
  }

  // Garment methods
  async getGarments(): Promise<Garment[]> {
    return Array.from(this.garments.values()).filter(g => !g.isArchived);
  }

  async getGarment(id: string): Promise<Garment | undefined> {
    return this.garments.get(id);
  }

  async createGarment(insertGarment: InsertGarment): Promise<Garment> {
    const id = randomUUID();
    const garment: Garment = {
      ...insertGarment,
      id,
      isArchived: false,
      createdAt: new Date()
    };
    this.garments.set(id, garment);
    return garment;
  }

  async updateGarment(id: string, garmentUpdate: Partial<InsertGarment>): Promise<Garment> {
    const existing = this.garments.get(id);
    if (!existing) throw new Error("Garment not found");
    
    const updated = { ...existing, ...garmentUpdate };
    this.garments.set(id, updated);
    return updated;
  }

  async deleteGarment(id: string): Promise<void> {
    this.garments.delete(id);
  }

  // Order methods
  async getOrders(): Promise<Order[]> {
    return Array.from(this.orders.values());
  }

  async getOrder(id: string): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async getOrdersByCustomer(customerId: string): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(o => o.customerId === customerId);
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = randomUUID();
    const order: Order = {
      ...insertOrder,
      id,
      createdAt: new Date()
    };
    this.orders.set(id, order);
    return order;
  }

  async updateOrder(id: string, orderUpdate: Partial<InsertOrder>): Promise<Order> {
    const existing = this.orders.get(id);
    if (!existing) throw new Error("Order not found");
    
    const updated = { ...existing, ...orderUpdate };
    this.orders.set(id, updated);
    return updated;
  }

  async deleteOrder(id: string): Promise<void> {
    this.orders.delete(id);
  }

  // Schedule methods
  async getSchedules(): Promise<Schedule[]> {
    return Array.from(this.schedules.values());
  }

  async getSchedule(id: string): Promise<Schedule | undefined> {
    return this.schedules.get(id);
  }

  async getSchedulesByCustomer(customerId: string): Promise<Schedule[]> {
    return Array.from(this.schedules.values()).filter(s => s.customerId === customerId);
  }

  async createSchedule(insertSchedule: InsertSchedule): Promise<Schedule> {
    const id = randomUUID();
    const schedule: Schedule = {
      ...insertSchedule,
      id,
      createdAt: new Date()
    };
    this.schedules.set(id, schedule);
    return schedule;
  }

  async updateSchedule(id: string, scheduleUpdate: Partial<InsertSchedule>): Promise<Schedule> {
    const existing = this.schedules.get(id);
    if (!existing) throw new Error("Schedule not found");
    
    const updated = { ...existing, ...scheduleUpdate };
    this.schedules.set(id, updated);
    return updated;
  }

  async deleteSchedule(id: string): Promise<void> {
    this.schedules.delete(id);
  }

  // Fitting methods
  async getFittings(): Promise<Fitting[]> {
    return Array.from(this.fittings.values());
  }

  async getFitting(id: string): Promise<Fitting | undefined> {
    return this.fittings.get(id);
  }

  async getFittingsByCustomer(customerId: string): Promise<Fitting[]> {
    return Array.from(this.fittings.values()).filter(f => f.customerId === customerId);
  }

  async createFitting(insertFitting: InsertFitting): Promise<Fitting> {
    const id = randomUUID();
    const fitting: Fitting = {
      ...insertFitting,
      id,
      createdAt: new Date()
    };
    this.fittings.set(id, fitting);
    return fitting;
  }

  async updateFitting(id: string, fittingUpdate: Partial<InsertFitting>): Promise<Fitting> {
    const existing = this.fittings.get(id);
    if (!existing) throw new Error("Fitting not found");
    
    const updated = { ...existing, ...fittingUpdate };
    this.fittings.set(id, updated);
    return updated;
  }

  async deleteFitting(id: string): Promise<void> {
    this.fittings.delete(id);
  }

  // Feedback methods
  async getFeedbacks(): Promise<Feedback[]> {
    return Array.from(this.feedbacks.values());
  }

  async getFeedback(id: string): Promise<Feedback | undefined> {
    return this.feedbacks.get(id);
  }

  async getFeedbacksByCustomer(customerId: string): Promise<Feedback[]> {
    return Array.from(this.feedbacks.values()).filter(f => f.customerId === customerId);
  }

  async getFeedbacksByGarment(garmentId: string): Promise<Feedback[]> {
    return Array.from(this.feedbacks.values()).filter(f => f.garmentId === garmentId);
  }

  async createFeedback(insertFeedback: InsertFeedback): Promise<Feedback> {
    const id = randomUUID();
    const feedback: Feedback = {
      ...insertFeedback,
      id,
      createdAt: new Date()
    };
    this.feedbacks.set(id, feedback);
    return feedback;
  }

  async updateFeedback(id: string, feedbackUpdate: Partial<InsertFeedback>): Promise<Feedback> {
    const existing = this.feedbacks.get(id);
    if (!existing) throw new Error("Feedback not found");
    
    const updated = { ...existing, ...feedbackUpdate };
    this.feedbacks.set(id, updated);
    return updated;
  }

  async deleteFeedback(id: string): Promise<void> {
    this.feedbacks.delete(id);
  }

  // Sales methods
  async getSales(): Promise<Sale[]> {
    return Array.from(this.sales.values());
  }

  async getSale(id: string): Promise<Sale | undefined> {
    return this.sales.get(id);
  }

  async getSalesByCustomer(customerId: string): Promise<Sale[]> {
    return Array.from(this.sales.values()).filter(s => s.customerId === customerId);
  }

  async getSalesByDateRange(startDate: Date, endDate: Date): Promise<Sale[]> {
    return Array.from(this.sales.values()).filter(s => {
      const saleDate = s.transactionDate ? new Date(s.transactionDate) : new Date();
      return saleDate >= startDate && saleDate <= endDate;
    });
  }

  async createSale(insertSale: InsertSale): Promise<Sale> {
    const id = randomUUID();
    const sale: Sale = {
      ...insertSale,
      id,
      transactionDate: insertSale.transactionDate || new Date()
    };
    this.sales.set(id, sale);
    return sale;
  }

  async updateSale(id: string, saleUpdate: Partial<InsertSale>): Promise<Sale> {
    const existing = this.sales.get(id);
    if (!existing) throw new Error("Sale not found");
    
    const updated = { ...existing, ...saleUpdate };
    this.sales.set(id, updated);
    return updated;
  }

  async deleteSale(id: string): Promise<void> {
    this.sales.delete(id);
  }

  // Analytics methods
  async getDashboardMetrics() {
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    const todaySales = Array.from(this.sales.values()).filter(s => {
      const saleDate = s.transactionDate ? new Date(s.transactionDate) : new Date();
      return saleDate.toDateString() === today.toDateString();
    });

    const pendingOrders = Array.from(this.orders.values()).filter(o => o.status === 'pending');
    
    const recentOrders = Array.from(this.orders.values())
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime())
      .slice(0, 5);

    const upcomingSchedules = Array.from(this.schedules.values())
      .filter(s => new Date(s.scheduledDate) >= today && s.status === 'scheduled')
      .sort((a, b) => new Date(a.scheduledDate).getTime() - new Date(b.scheduledDate).getTime())
      .slice(0, 5);

    const dailySales = todaySales.reduce((sum, sale) => sum + parseFloat(sale.amount || '0'), 0);
    const dailyCustomers = new Set(todaySales.map(s => s.customerId)).size;
    const avgOrderValue = this.orders.size > 0 
      ? Array.from(this.orders.values()).reduce((sum, order) => sum + parseFloat(order.totalAmount || '0'), 0) / this.orders.size
      : 0;

    // Generate sales over time data (last 30 days)
    const salesOverTime = [];
    for (let i = 29; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      
      const daySales = Array.from(this.sales.values()).filter(s => {
        const saleDate = s.transactionDate ? new Date(s.transactionDate) : new Date();
        return saleDate.toDateString() === date.toDateString();
      });
      
      const amount = daySales.reduce((sum, sale) => sum + parseFloat(sale.amount || '0'), 0);
      salesOverTime.push({ date: dateStr, amount });
    }

    // Get top garments by sales
    const garmentSales = new Map<string, number>();
    Array.from(this.sales.values()).forEach(sale => {
      const order = this.orders.get(sale.orderId);
      if (order?.garmentId) {
        const current = garmentSales.get(order.garmentId) || 0;
        garmentSales.set(order.garmentId, current + parseFloat(sale.amount || '0'));
      }
    });

    const topGarments = Array.from(garmentSales.entries())
      .map(([garmentId, sales]) => {
        const garment = this.garments.get(garmentId);
        return {
          garmentId,
          name: garment?.name || 'Unknown',
          sales
        };
      })
      .sort((a, b) => b.sales - a.sales)
      .slice(0, 5);

    return {
      dailySales,
      dailyCustomers,
      pendingOrders: pendingOrders.length,
      avgOrderValue,
      salesOverTime,
      topGarments,
      recentOrders,
      upcomingSchedules
    };
  }
}

import { DBStorage } from "./dbStorage.js";
export const storage = new DBStorage();
