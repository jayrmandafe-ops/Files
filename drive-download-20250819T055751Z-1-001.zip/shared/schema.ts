import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, decimal, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const customers = pgTable("customers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  email: text("email"),
  phone: text("phone"),
  address: text("address"),
  dateOfBirth: timestamp("date_of_birth"),
  notes: text("notes"),
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const garments = pgTable("garments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  category: text("category").notNull(), // Traditional, Formal, Evening, etc.
  silhouette: text("silhouette"),
  fabricUsed: text("fabric_used"),
  description: text("description"),
  notes: text("notes"),
  isArchived: boolean("is_archived").default(false),
  photoUrl: text("photo_url"),
  rentalPrice: decimal("rental_price", { precision: 10, scale: 2 }),
  purchasePrice: decimal("purchase_price", { precision: 10, scale: 2 }),
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const orders = pgTable("orders", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  customerId: varchar("customer_id").notNull().references(() => customers.id),
  garmentId: varchar("garment_id").notNull().references(() => garments.id),
  orderType: text("order_type").notNull(), // rental, custom, purchase
  status: text("status").notNull().default("pending"), // pending, confirmed, in_progress, completed, cancelled
  totalAmount: decimal("total_amount", { precision: 10, scale: 2 }).notNull(),
  depositAmount: decimal("deposit_amount", { precision: 10, scale: 2 }),
  balanceAmount: decimal("balance_amount", { precision: 10, scale: 2 }),
  rentalDuration: integer("rental_duration"), // in days
  pickupDate: timestamp("pickup_date"),
  returnDate: timestamp("return_date"),
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const schedules = pgTable("schedules", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  customerId: varchar("customer_id").notNull().references(() => customers.id),
  orderId: varchar("order_id").references(() => orders.id),
  type: text("type").notNull(), // pickup, return, fitting, consultation
  scheduledDate: timestamp("scheduled_date").notNull(),
  status: text("status").notNull().default("scheduled"), // scheduled, completed, cancelled, rescheduled
  notes: text("notes"),
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const fittings = pgTable("fittings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  customerId: varchar("customer_id").notNull().references(() => customers.id),
  orderId: varchar("order_id").references(() => orders.id),
  fittingType: text("fitting_type").notNull(), // individual, group
  category: text("category").notNull(), // first_use, for_rent, to_own, modified
  firstFittingDate: timestamp("first_fitting_date"),
  lastFittingDate: timestamp("last_fitting_date"),
  measurements: jsonb("measurements"), // Store measurements as JSON
  totalAmount: decimal("total_amount", { precision: 10, scale: 2 }),
  depositAmount: decimal("deposit_amount", { precision: 10, scale: 2 }),
  balanceAmount: decimal("balance_amount", { precision: 10, scale: 2 }),
  pickupDate: timestamp("pickup_date"),
  isWalkIn: boolean("is_walk_in").default(false),
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const feedback = pgTable("feedback", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  customerId: varchar("customer_id").notNull().references(() => customers.id),
  orderId: varchar("order_id").references(() => orders.id),
  garmentId: varchar("garment_id").references(() => garments.id),
  rating: integer("rating").notNull(), // 1-5
  review: text("review"),
  liked: boolean("liked").default(false),
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const sales = pgTable("sales", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orderId: varchar("order_id").notNull().references(() => orders.id),
  customerId: varchar("customer_id").notNull().references(() => customers.id),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  paymentMethod: text("payment_method"),
  transactionDate: timestamp("transaction_date").default(sql`now()`),
  salesType: text("sales_type").notNull(), // rental, purchase, fitting_fee, etc.
});

// Relations
export const customersRelations = relations(customers, ({ many }) => ({
  orders: many(orders),
  schedules: many(schedules),
  fittings: many(fittings),
  feedback: many(feedback),
  sales: many(sales),
}));

export const garmentsRelations = relations(garments, ({ many }) => ({
  orders: many(orders),
  feedback: many(feedback),
}));

export const ordersRelations = relations(orders, ({ one, many }) => ({
  customer: one(customers, {
    fields: [orders.customerId],
    references: [customers.id],
  }),
  garment: one(garments, {
    fields: [orders.garmentId],
    references: [garments.id],
  }),
  schedules: many(schedules),
  fittings: many(fittings),
  feedback: many(feedback),
  sales: many(sales),
}));

export const schedulesRelations = relations(schedules, ({ one }) => ({
  customer: one(customers, {
    fields: [schedules.customerId],
    references: [customers.id],
  }),
  order: one(orders, {
    fields: [schedules.orderId],
    references: [orders.id],
  }),
}));

export const fittingsRelations = relations(fittings, ({ one }) => ({
  customer: one(customers, {
    fields: [fittings.customerId],
    references: [customers.id],
  }),
  order: one(orders, {
    fields: [fittings.orderId],
    references: [orders.id],
  }),
}));

export const feedbackRelations = relations(feedback, ({ one }) => ({
  customer: one(customers, {
    fields: [feedback.customerId],
    references: [customers.id],
  }),
  order: one(orders, {
    fields: [feedback.orderId],
    references: [orders.id],
  }),
  garment: one(garments, {
    fields: [feedback.garmentId],
    references: [garments.id],
  }),
}));

export const salesRelations = relations(sales, ({ one }) => ({
  order: one(orders, {
    fields: [sales.orderId],
    references: [orders.id],
  }),
  customer: one(customers, {
    fields: [sales.customerId],
    references: [customers.id],
  }),
}));

// Insert schemas
export const insertCustomerSchema = createInsertSchema(customers).omit({
  id: true,
  createdAt: true,
});

export const insertGarmentSchema = createInsertSchema(garments).omit({
  id: true,
  createdAt: true,
});

export const insertOrderSchema = createInsertSchema(orders).omit({
  id: true,
  createdAt: true,
});

export const insertScheduleSchema = createInsertSchema(schedules).omit({
  id: true,
  createdAt: true,
});

export const insertFittingSchema = createInsertSchema(fittings).omit({
  id: true,
  createdAt: true,
});

export const insertFeedbackSchema = createInsertSchema(feedback).omit({
  id: true,
  createdAt: true,
});

export const insertSaleSchema = createInsertSchema(sales).omit({
  id: true,
});

// Types
export type Customer = typeof customers.$inferSelect;
export type InsertCustomer = z.infer<typeof insertCustomerSchema>;

export type Garment = typeof garments.$inferSelect;
export type InsertGarment = z.infer<typeof insertGarmentSchema>;

export type Order = typeof orders.$inferSelect;
export type InsertOrder = z.infer<typeof insertOrderSchema>;

export type Schedule = typeof schedules.$inferSelect;
export type InsertSchedule = z.infer<typeof insertScheduleSchema>;

export type Fitting = typeof fittings.$inferSelect;
export type InsertFitting = z.infer<typeof insertFittingSchema>;

export type Feedback = typeof feedback.$inferSelect;
export type InsertFeedback = z.infer<typeof insertFeedbackSchema>;

export type Sale = typeof sales.$inferSelect;
export type InsertSale = z.infer<typeof insertSaleSchema>;

// User schema (keeping original)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
